﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercise1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void send_Click(object sender, EventArgs e)
        {
            txtReceipt.Text = "";

            double tot = 0;

            if (chkBroccoli.Checked)
            {
                tot += 4 * Convert.ToInt32(numBroccoli.Value);
                txtReceipt.Text += "Broccoli -- " + Convert.ToInt32(numBroccoli.Value) + "\n";
            }
            if (chkTomatoes.Checked)
            {
                tot += 3 * Convert.ToInt32(numTomatoes.Value);
                txtReceipt.Text += "Tomatoes -- " + Convert.ToInt32(numTomatoes.Value) + "\n";
            }
            if (chkMushrooms.Checked)
            {
                tot += 3.25 * Convert.ToInt32(numMushrooms.Value);
                txtReceipt.Text += "Mushrooms -- " + Convert.ToInt32(numMushrooms.Value) + "\n";
            }
            if (chkBeans.Checked)
            {
                tot += 2.75 * Convert.ToInt32(numBeans.Value);
                txtReceipt.Text += "Beansprouts -- " + Convert.ToInt32(numBeans.Value) + "\n";
            }
            if (chkLettuce.Checked)
            {
                tot += 2.50 * Convert.ToInt32(numLettuce.Value);
                txtReceipt.Text += "Lettuce -- " + Convert.ToInt32(numLettuce.Value) + "\n";
            }
            if (chkGrapes.Checked)
            {
                tot += 3.75 * Convert.ToInt32(numGrapes.Value);
                txtReceipt.Text += "Grapes -- " + Convert.ToInt32(numGrapes.Value) + "\n";
            }
            if (chkCucumbers.Checked)
            {
                tot += 3.25 * Convert.ToInt32(numCucumbers.Value);
                txtReceipt.Text += "Cucumbers -- " + Convert.ToInt32(numCucumbers.Value) + "\n";
            }
            if (chkCarrots.Checked)
            {
                tot += 2.50 * Convert.ToInt32(numCarrots.Value);
                txtReceipt.Text += "Carrots -- " + Convert.ToInt32(numCarrots.Value) + "\n";
            }
            if (chkCelery.Checked)
            {
                tot += 1.75 * Convert.ToInt32(numCelery.Value);
                txtReceipt.Text += "Celery -- " + Convert.ToInt32(numCelery.Value) + "\n";
            }
            if (chkOnions.Checked)
            {
                tot += 2 * Convert.ToInt32(numOnions.Value);
                txtReceipt.Text += "Onions -- " + Convert.ToInt32(numOnions.Value) + "\n";
            }
            if (chkSpring.Checked)
            {
                tot += 2.25 * Convert.ToInt32(numSpring.Value);
                txtReceipt.Text += "Spring Onions -- " + Convert.ToInt32(numSpring.Value) + "\n";
            }
            if (chkCoriander.Checked)
            {
                tot += 3 * Convert.ToInt32(numCoriander.Value);
                txtReceipt.Text += "Coriander -- " + Convert.ToInt32(numCoriander.Value) + "\n";
            }
            if (chkMeatballs.Checked)
            {
                tot += 6 * Convert.ToInt32(numMeatballs.Value);
                txtReceipt.Text += "Meatballs -- " + Convert.ToInt32(numMeatballs.Value) + "\n";
            }
            if (chkBeef.Checked)
            {
                tot += 7 * Convert.ToInt32(numBeef.Value);
                txtReceipt.Text += "Beef -- " + Convert.ToInt32(numBeef.Value) + "\n";
            }
            if (chkBacon.Checked)
            {
                tot += 5.75 * Convert.ToInt32(numBacon.Value);
                txtReceipt.Text += "Bacon -- " + Convert.ToInt32(numBacon.Value) + "\n";
            }
            if (chkSmokedHam.Checked)
            {
                tot += 6.25 * Convert.ToInt32(numSmokedHam.Value);
                txtReceipt.Text += "Smoked Ham -- " + Convert.ToInt32(numSmokedHam.Value) + "\n";
            }
            if (chkFish.Checked)
            {
                tot += 8 * Convert.ToInt32(numFish.Value);
                txtReceipt.Text += "Fish -- " + Convert.ToInt32(numFish.Value) + "\n";
            }
            if (chkSmokedFish.Checked)
            {
                tot += 8.50 * Convert.ToInt32(numSmokedFish.Value);
                txtReceipt.Text += "Smoked Fish -- " + Convert.ToInt32(numSmokedFish.Value) + "\n";
            }
            if (chkRice.Checked)
            {
                tot += 6.25 * Convert.ToInt32(numRice.Value);
                txtReceipt.Text += "Rice -- " + Convert.ToInt32(numRice.Value) + "\n";
            }
            if (chkWheat.Checked)
            {
                tot += 5 * Convert.ToInt32(numWheat.Value);
                txtReceipt.Text += "Wheat -- " + Convert.ToInt32(numWheat.Value) + "\n";
            }
            if (chkCheese.Checked)
            {
                tot += 4.25 * Convert.ToInt32(numCheese.Value);
                txtReceipt.Text += "Cheese -- " + Convert.ToInt32(numCheese.Value) + "\n";
            }
            if (chkVodka.Checked)
            {
                tot += 11.25 * Convert.ToInt32(numVodka.Value);
                txtReceipt.Text += "Vodka -- " + Convert.ToInt32(numVodka.Value) + "\n";
            }
            if (chkWine.Checked)
            {
                tot += 10.50 * Convert.ToInt32(numWIne.Value);
                txtReceipt.Text += "Wine -- " + Convert.ToInt32(numWIne.Value) + "\n";
            }
            if (chkWhiskey.Checked)
            {
                tot += 12 * Convert.ToInt32(numWhiskey.Value);
                txtReceipt.Text += "Whiskey -- " + Convert.ToInt32(numWhiskey.Value) + "\n";
            }
            if (chkRum.Checked)
            {
                tot += 11.75 * Convert.ToInt32(numRum.Value);
                txtReceipt.Text += "Rum -- " + Convert.ToInt32(numRum.Value) + "\n";
            }
            if (chkGin.Checked)
            {
                tot += 12.50 * Convert.ToInt32(numGin.Value);
                txtReceipt.Text += "Gin -- " + Convert.ToInt32(numGin.Value) + "\n";
            }
            if (chkSake.Checked)
            {
                tot += 11 * Convert.ToInt32(numSake.Value);
                txtReceipt.Text += "Sake -- " + Convert.ToInt32(numSake.Value) + "\n";
            }
            if (chkTequila.Checked)
            {
                tot += 11.75 * Convert.ToInt32(numTequila.Value);
                txtReceipt.Text += "Tequila -- " + Convert.ToInt32(numTequila.Value) + "\n";
            }

            double tax = tot * .07;
            double total = tot + tax;


            txtSubTotal.Text = String.Format("{0:0.00}", tot);
            txtTax.Text = String.Format("{0:0.00}", tax);
            txtTotal.Text = String.Format("{0:0.00}", total);

            txtReceipt.Text += " " + "\n";
            txtReceipt.Text += "Total -- $" + String.Format("{0:0.00}", total) + "\n";

            chkBroccoli.Checked = false;
            chkTomatoes.Checked = false;
            chkMushrooms.Checked = false;
            chkBeans.Checked = false;
            chkLettuce.Checked = false;
            chkGrapes.Checked = false;
            chkCucumbers.Checked = false;
            chkCarrots.Checked = false;
            chkCelery.Checked = false;
            chkOnions.Checked = false;
            chkSpring.Checked = false;
            chkCoriander.Checked = false;
            chkMeatballs.Checked = false;
            chkBeef.Checked = false;
            chkBacon.Checked = false;
            chkSmokedHam.Checked = false;
            chkFish.Checked = false;
            chkSmokedFish.Checked = false;
            chkRice.Checked = false;
            chkWheat.Checked = false;
            chkCheese.Checked = false;
            chkVodka.Checked = false;
            chkWine.Checked = false;
            chkWhiskey.Checked = false;
            chkRum.Checked = false;
            chkGin.Checked = false;
            chkSake.Checked = false;
            chkTequila.Checked = false;

            numBroccoli.Value = 0;
            numTomatoes.Value = 0;
            numMushrooms.Value = 0;
            numBeans.Value = 0;
            numLettuce.Value = 0;
            numGrapes.Value = 0;
            numCucumbers.Value = 0;
            numCarrots.Value = 0;
            numCelery.Value = 0;
            numOnions.Value = 0;
            numSpring.Value = 0;
            numCoriander.Value = 0;
            numMeatballs.Value = 0;
            numBeef.Value = 0;
            numBacon.Value = 0;
            numSmokedHam.Value = 0;
            numFish.Value = 0;
            numSmokedFish.Value = 0;
            numRice.Value = 0;
            numWheat.Value = 0;
            numCheese.Value = 0;
            numVodka.Value = 0;
            numWIne.Value = 0;
            numWhiskey.Value = 0;
            numRum.Value = 0;
            numGin.Value = 0;
            numSake.Value = 0;
            numTequila.Value = 0;
        }
        private void clear_Click(object sender, EventArgs e)
        {
            txtSubTotal.Text = "";
            txtTax.Text = "";
            txtTotal.Text = "";
            txtReceipt.Text = "";

            chkBroccoli.Checked = false;
            chkTomatoes.Checked = false;
            chkMushrooms.Checked = false;
            chkBeans.Checked = false;
            chkLettuce.Checked = false;
            chkGrapes.Checked = false;
            chkCucumbers.Checked = false;
            chkCarrots.Checked = false;
            chkCelery.Checked = false;
            chkOnions.Checked = false;
            chkSpring.Checked = false;
            chkCoriander.Checked = false;
            chkMeatballs.Checked = false;
            chkBeef.Checked = false;
            chkBacon.Checked = false;
            chkSmokedHam.Checked = false;
            chkFish.Checked = false;
            chkSmokedFish.Checked = false;
            chkRice.Checked = false;
            chkWheat.Checked = false;
            chkCheese.Checked = false;
            chkVodka.Checked = false;
            chkWine.Checked = false;
            chkWhiskey.Checked = false;
            chkRum.Checked = false;
            chkGin.Checked = false;
            chkSake.Checked = false;
            chkTequila.Checked = false;

            numBroccoli.Value = 0;
            numTomatoes.Value = 0;
            numMushrooms.Value = 0;
            numBeans.Value = 0;
            numLettuce.Value = 0;
            numGrapes.Value = 0;
            numCucumbers.Value = 0;
            numCarrots.Value = 0;
            numCelery.Value = 0;
            numOnions.Value = 0;
            numSpring.Value = 0;
            numCoriander.Value = 0;
            numMeatballs.Value = 0;
            numBeef.Value = 0;
            numBacon.Value = 0;
            numSmokedHam.Value = 0;
            numFish.Value = 0;
            numSmokedFish.Value = 0;
            numRice.Value = 0;
            numWheat.Value = 0;
            numCheese.Value = 0;
            numVodka.Value = 0;
            numWIne.Value = 0;
            numWhiskey.Value = 0;
            numRum.Value = 0;
            numGin.Value = 0;
            numSake.Value = 0;
            numTequila.Value = 0;
        }
        private void close_Click(object sender, EventArgs e)
        {
            Close();
        } 

        private void new2_Click(object sender, EventArgs e)
        {
            txtSubTotal.Text = "";
            txtTax.Text = "";
            txtTotal.Text = "";
            txtReceipt.Text = "";

            chkBroccoli.Checked = false;
            chkTomatoes.Checked = false;
            chkMushrooms.Checked = false;
            chkBeans.Checked = false;
            chkLettuce.Checked = false;
            chkGrapes.Checked = false;
            chkCucumbers.Checked = false;
            chkCarrots.Checked = false;
            chkCelery.Checked = false;
            chkOnions.Checked = false;
            chkSpring.Checked = false;
            chkCoriander.Checked = false;
            chkMeatballs.Checked = false;
            chkBeef.Checked = false;
            chkBacon.Checked = false;
            chkSmokedHam.Checked = false;
            chkFish.Checked = false;
            chkSmokedFish.Checked = false;
            chkRice.Checked = false;
            chkWheat.Checked = false;
            chkCheese.Checked = false;
            chkVodka.Checked = false;
            chkWine.Checked = false;
            chkWhiskey.Checked = false;
            chkRum.Checked = false;
            chkGin.Checked = false;
            chkSake.Checked = false;
            chkTequila.Checked = false;

            numBroccoli.Value = 0;
            numTomatoes.Value = 0;
            numMushrooms.Value = 0;
            numBeans.Value = 0;
            numLettuce.Value = 0;
            numGrapes.Value = 0;
            numCucumbers.Value = 0;
            numCarrots.Value = 0;
            numCelery.Value = 0;
            numOnions.Value = 0;
            numSpring.Value = 0;
            numCoriander.Value = 0;
            numMeatballs.Value = 0;
            numBeef.Value = 0;
            numBacon.Value = 0;
            numSmokedHam.Value = 0;
            numFish.Value = 0;
            numSmokedFish.Value = 0;
            numRice.Value = 0;
            numWheat.Value = 0;
            numCheese.Value = 0;
            numVodka.Value = 0;
            numWIne.Value = 0;
            numWhiskey.Value = 0;
            numRum.Value = 0;
            numGin.Value = 0;
            numSake.Value = 0;
            numTequila.Value = 0;
        }
        private void cart2_Click(object sender, EventArgs e)
        {
            txtReceipt.Text = "";

            double tot = 0;

            if (chkBroccoli.Checked)
            {
                tot += 4 * Convert.ToInt32(numBroccoli.Value);
                txtReceipt.Text += "Broccoli -- " + Convert.ToInt32(numBroccoli.Value) + "\n";
            }
            if (chkTomatoes.Checked)
            {
                tot += 3 * Convert.ToInt32(numTomatoes.Value);
                txtReceipt.Text += "Tomatoes -- " + Convert.ToInt32(numTomatoes.Value) + "\n";
            }
            if (chkMushrooms.Checked)
            {
                tot += 3.25 * Convert.ToInt32(numMushrooms.Value);
                txtReceipt.Text += "Mushrooms -- " + Convert.ToInt32(numMushrooms.Value) + "\n";
            }
            if (chkBeans.Checked)
            {
                tot += 2.75 * Convert.ToInt32(numBeans.Value);
                txtReceipt.Text += "Beansprouts -- " + Convert.ToInt32(numBeans.Value) + "\n";
            }
            if (chkLettuce.Checked)
            {
                tot += 2.50 * Convert.ToInt32(numLettuce.Value);
                txtReceipt.Text += "Lettuce -- " + Convert.ToInt32(numLettuce.Value) + "\n";
            }
            if (chkGrapes.Checked)
            {
                tot += 3.75 * Convert.ToInt32(numGrapes.Value);
                txtReceipt.Text += "Grapes -- " + Convert.ToInt32(numGrapes.Value) + "\n";
            }
            if (chkCucumbers.Checked)
            {
                tot += 3.25 * Convert.ToInt32(numCucumbers.Value);
                txtReceipt.Text += "Cucumbers -- " + Convert.ToInt32(numCucumbers.Value) + "\n";
            }
            if (chkCarrots.Checked)
            {
                tot += 2.50 * Convert.ToInt32(numCarrots.Value);
                txtReceipt.Text += "Carrots -- " + Convert.ToInt32(numCarrots.Value) + "\n";
            }
            if (chkCelery.Checked)
            {
                tot += 1.75 * Convert.ToInt32(numCelery.Value);
                txtReceipt.Text += "Celery -- " + Convert.ToInt32(numCelery.Value) + "\n";
            }
            if (chkOnions.Checked)
            {
                tot += 2 * Convert.ToInt32(numOnions.Value);
                txtReceipt.Text += "Onions -- " + Convert.ToInt32(numOnions.Value) + "\n";
            }
            if (chkSpring.Checked)
            {
                tot += 2.25 * Convert.ToInt32(numSpring.Value);
                txtReceipt.Text += "Spring Onions -- " + Convert.ToInt32(numSpring.Value) + "\n";
            }
            if (chkCoriander.Checked)
            {
                tot += 3 * Convert.ToInt32(numCoriander.Value);
                txtReceipt.Text += "Coriander -- " + Convert.ToInt32(numCoriander.Value) + "\n";
            }
            if (chkMeatballs.Checked)
            {
                tot += 6 * Convert.ToInt32(numMeatballs.Value);
                txtReceipt.Text += "Meatballs -- " + Convert.ToInt32(numMeatballs.Value) + "\n";
            }
            if (chkBeef.Checked)
            {
                tot += 7 * Convert.ToInt32(numBeef.Value);
                txtReceipt.Text += "Beef -- " + Convert.ToInt32(numBeef.Value) + "\n";
            }
            if (chkBacon.Checked)
            {
                tot += 5.75 * Convert.ToInt32(numBacon.Value);
                txtReceipt.Text += "Bacon -- " + Convert.ToInt32(numBacon.Value) + "\n";
            }
            if (chkSmokedHam.Checked)
            {
                tot += 6.25 * Convert.ToInt32(numSmokedHam.Value);
                txtReceipt.Text += "Smoked Ham -- " + Convert.ToInt32(numSmokedHam.Value) + "\n";
            }
            if (chkFish.Checked)
            {
                tot += 8 * Convert.ToInt32(numFish.Value);
                txtReceipt.Text += "Fish -- " + Convert.ToInt32(numFish.Value) + "\n";
            }
            if (chkSmokedFish.Checked)
            {
                tot += 8.50 * Convert.ToInt32(numSmokedFish.Value);
                txtReceipt.Text += "Smoked Fish -- " + Convert.ToInt32(numSmokedFish.Value) + "\n";
            }
            if (chkRice.Checked)
            {
                tot += 6.25 * Convert.ToInt32(numRice.Value);
                txtReceipt.Text += "Rice -- " + Convert.ToInt32(numRice.Value) + "\n";
            }
            if (chkWheat.Checked)
            {
                tot += 5 * Convert.ToInt32(numWheat.Value);
                txtReceipt.Text += "Wheat -- " + Convert.ToInt32(numWheat.Value) + "\n";
            }
            if (chkCheese.Checked)
            {
                tot += 4.25 * Convert.ToInt32(numCheese.Value);
                txtReceipt.Text += "Cheese -- " + Convert.ToInt32(numCheese.Value) + "\n";
            }
            if (chkVodka.Checked)
            {
                tot += 11.25 * Convert.ToInt32(numVodka.Value);
                txtReceipt.Text += "Vodka -- " + Convert.ToInt32(numVodka.Value) + "\n";
            }
            if (chkWine.Checked)
            {
                tot += 10.50 * Convert.ToInt32(numWIne.Value);
                txtReceipt.Text += "Wine -- " + Convert.ToInt32(numWIne.Value) + "\n";
            }
            if (chkWhiskey.Checked)
            {
                tot += 12 * Convert.ToInt32(numWhiskey.Value);
                txtReceipt.Text += "Whiskey -- " + Convert.ToInt32(numWhiskey.Value) + "\n";
            }
            if (chkRum.Checked)
            {
                tot += 11.75 * Convert.ToInt32(numRum.Value);
                txtReceipt.Text += "Rum -- " + Convert.ToInt32(numRum.Value) + "\n";
            }
            if (chkGin.Checked)
            {
                tot += 12.50 * Convert.ToInt32(numGin.Value);
                txtReceipt.Text += "Gin -- " + Convert.ToInt32(numGin.Value) + "\n";
            }
            if (chkSake.Checked)
            {
                tot += 11 * Convert.ToInt32(numSake.Value);
                txtReceipt.Text += "Sake -- " + Convert.ToInt32(numSake.Value) + "\n";
            }
            if (chkTequila.Checked)
            {
                tot += 11.75 * Convert.ToInt32(numTequila.Value);
                txtReceipt.Text += "Tequila -- " + Convert.ToInt32(numTequila.Value) + "\n";
            }

            double tax = tot * .07;
            double total = tot + tax;


            txtSubTotal.Text = String.Format("{0:0.00}", tot);
            txtTax.Text = String.Format("{0:0.00}", tax);
            txtTotal.Text = String.Format("{0:0.00}", total);

            txtReceipt.Text += " " + "\n";
            txtReceipt.Text += "Total -- $" + String.Format("{0:0.00}", total) + "\n";

            chkBroccoli.Checked = false;
            chkTomatoes.Checked = false;
            chkMushrooms.Checked = false;
            chkBeans.Checked = false;
            chkLettuce.Checked = false;
            chkGrapes.Checked = false;
            chkCucumbers.Checked = false;
            chkCarrots.Checked = false;
            chkCelery.Checked = false;
            chkOnions.Checked = false;
            chkSpring.Checked = false;
            chkCoriander.Checked = false;
            chkMeatballs.Checked = false;
            chkBeef.Checked = false;
            chkBacon.Checked = false;
            chkSmokedHam.Checked = false;
            chkFish.Checked = false;
            chkSmokedFish.Checked = false;
            chkRice.Checked = false;
            chkWheat.Checked = false;
            chkCheese.Checked = false;
            chkVodka.Checked = false;
            chkWine.Checked = false;
            chkWhiskey.Checked = false;
            chkRum.Checked = false;
            chkGin.Checked = false;
            chkSake.Checked = false;
            chkTequila.Checked = false;

            numBroccoli.Value = 0;
            numTomatoes.Value = 0;
            numMushrooms.Value = 0;
            numBeans.Value = 0;
            numLettuce.Value = 0;
            numGrapes.Value = 0;
            numCucumbers.Value = 0;
            numCarrots.Value = 0;
            numCelery.Value = 0;
            numOnions.Value = 0;
            numSpring.Value = 0;
            numCoriander.Value = 0;
            numMeatballs.Value = 0;
            numBeef.Value = 0;
            numBacon.Value = 0;
            numSmokedHam.Value = 0;
            numFish.Value = 0;
            numSmokedFish.Value = 0;
            numRice.Value = 0;
            numWheat.Value = 0;
            numCheese.Value = 0;
            numVodka.Value = 0;
            numWIne.Value = 0;
            numWhiskey.Value = 0;
            numRum.Value = 0;
            numGin.Value = 0;
            numSake.Value = 0;
            numTequila.Value = 0;
        }
        
        private void save2_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.Filter = "Text Files|*.rtf";
            saveFileDialog1.Title = "Save Order Files";

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtReceipt.SaveFile(saveFileDialog1.FileName);
            }
        }
        private void folder2_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();
        }

        private void save4_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.Filter = "Text Files|*.rtf";
            saveFileDialog1.Title = "Save Order Files";

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtReceipt.SaveFile(saveFileDialog1.FileName);
            }
        }
        private void open4_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();
        }

        private void save1_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.Filter = "Text Files|*.rtf";
            saveFileDialog1.Title = "Save Order Files";

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtReceipt.SaveFile(saveFileDialog1.FileName);
            }
        }
        private void open1_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();
        }

        private void broc_Click(object sender, EventArgs e)
        {
            chkBroccoli.Checked = true;
        }
        private void tomatoes_Click(object sender, EventArgs e)
        {
            chkTomatoes.Checked = true;
        }
        private void mushrooms_Click(object sender, EventArgs e)
        {
            chkMushrooms.Checked = true;
        }
        private void beans_Click(object sender, EventArgs e)
        {
            chkBeans.Checked = true;
        }
        private void lettuce_Click(object sender, EventArgs e)
        {
            chkLettuce.Checked = true;
        }
        private void grapes_Click(object sender, EventArgs e)
        {
            chkGrapes.Checked = true;
        }
        private void cucumber_Click(object sender, EventArgs e)
        {
            chkCucumbers.Checked = true;
        }
        private void carrots_Click(object sender, EventArgs e)
        {
            chkCarrots.Checked = true;
        }
        private void celery_Click(object sender, EventArgs e)
        {
            chkCelery.Checked = true;
        }
        private void onions_Click(object sender, EventArgs e)
        {
            chkOnions.Checked = true;
        }
        private void springO_Click(object sender, EventArgs e)
        {
            chkSpring.Checked = true;
        }
        private void coriander_Click(object sender, EventArgs e)
        {
            chkCoriander.Checked = true;
        }
        private void allV_Click(object sender, EventArgs e)
        {
            chkBroccoli.Checked = true;
            chkTomatoes.Checked = true;
            chkMushrooms.Checked = true;
            chkBeans.Checked = true;
            chkLettuce.Checked = true;
            chkGrapes.Checked = true;
            chkCucumbers.Checked = true;
            chkCarrots.Checked = true;
            chkCelery.Checked = true;
            chkOnions.Checked = true;
            chkSpring.Checked = true;
            chkCoriander.Checked = true;
        }
        private void meatballs_Click(object sender, EventArgs e)
        {
            chkMeatballs.Checked = true;
        }
        private void beef_Click(object sender, EventArgs e)
        {
            chkBeef.Checked = true;
        }
        private void bacon_Click(object sender, EventArgs e)
        {
            chkBacon.Checked = true;
        }
        private void smokedHam_Click(object sender, EventArgs e)
        {
            chkSmokedHam.Checked = true;
        }
        private void fish_Click(object sender, EventArgs e)
        {
            chkFish.Checked = true;
        }
        private void smokedFish_Click(object sender, EventArgs e)
        {
            chkSmokedFish.Checked = true;
        }
        private void allM_Click(object sender, EventArgs e)
        {
            chkMeatballs.Checked = true;
            chkBacon.Checked = true;
            chkBeef.Checked = true;
            chkSmokedHam.Checked = true;
            chkFish.Checked = true;
            chkSmokedFish.Checked = true;
        }
        private void rice_Click(object sender, EventArgs e)
        {
            chkRice.Checked = true;
        }
        private void wheat_Click(object sender, EventArgs e)
        {
            chkWheat.Checked = true;
        }
        private void allG_Click(object sender, EventArgs e)
        {
            chkRice.Checked = true;
            chkWheat.Checked = true;
        }
        private void cheese_Click(object sender, EventArgs e)
        {
            chkCheese.Checked = true;
        }
        private void vodka_Click(object sender, EventArgs e)
        {
            chkVodka.Checked = true;
        }
        private void wine_Click(object sender, EventArgs e)
        {
            chkWine.Checked = true;
        }
        private void whiskey_Click(object sender, EventArgs e)
        {
            chkWhiskey.Checked = true;
        }
        private void rum_Click(object sender, EventArgs e)
        {
            chkRum.Checked = true;
        }
        private void gin_Click(object sender, EventArgs e)
        {
            chkGin.Checked = true;
        }
        private void sake_Click(object sender, EventArgs e)
        {
            chkSake.Checked = true;
        }
        private void tequila_Click(object sender, EventArgs e)
        {
            chkTequila.Checked = true;
        }
        private void allA_Click(object sender, EventArgs e)
        {
            chkVodka.Checked = true;
            chkWine.Checked = true;
            chkWhiskey.Checked = true;
            chkRum.Checked = true;
            chkGin.Checked = true;
            chkSake.Checked = true;
            chkTequila.Checked = true;
        }

        private void chkBroccoli_CheckedChanged(object sender, EventArgs e)
        {
            if (chkBroccoli.Checked)
            {
                numBroccoli.Enabled = true;
                numBroccoli.ReadOnly = false;
            } else
            {
                numBroccoli.Value = 0;
                numBroccoli.Enabled = false;
                numBroccoli.ReadOnly = true;
            }
        }

        private void chkTomatoes_CheckedChanged(object sender, EventArgs e)
        {
            if (chkTomatoes.Checked)
            {
                numTomatoes.Enabled = true;
                numTomatoes.ReadOnly = false;
            }
            else
            {
                numTomatoes.Value = 0;
                numTomatoes.Enabled = false;
                numTomatoes.ReadOnly = true;
            }
        }

        private void chkMushrooms_CheckedChanged(object sender, EventArgs e)
        {
            if (chkMushrooms.Checked)
            {
                numMushrooms.Enabled = true;
                numMushrooms.ReadOnly = false;
            }
            else
            {
                numMushrooms.Value = 0;
                numMushrooms.Enabled = false;
                numMushrooms.ReadOnly = true;
            }
        }

        private void chkBeans_CheckedChanged(object sender, EventArgs e)
        {
            if (chkBeans.Checked)
            {
                numBeans.Enabled = true;
                numBeans.ReadOnly = false;
            }
            else
            {
                numBeans.Value = 0;
                numBeans.Enabled = false;
                numBeans.ReadOnly = true;
            }
        }

        private void chkLettuce_CheckedChanged(object sender, EventArgs e)
        {
            if (chkLettuce.Checked)
            {
                numLettuce.Enabled = true;
                numLettuce.ReadOnly = false;
            }
            else
            {
                numLettuce.Value = 0;
                numLettuce.Enabled = false;
                numLettuce.ReadOnly = true;
            }
        }

        private void chkGrapes_CheckedChanged(object sender, EventArgs e)
        {
            if (chkGrapes.Checked)
            {
                numGrapes.Enabled = true;
                numGrapes.ReadOnly = false;
            }
            else
            {
                numGrapes.Value = 0;
                numGrapes.Enabled = false;
                numGrapes.ReadOnly = true;
            }
        }

        private void chkCucumbers_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCucumbers.Checked)
            {
                numCucumbers.Enabled = true;
                numCucumbers.ReadOnly = false;
            }
            else
            {
                numCucumbers.Value = 0;
                numCucumbers.Enabled = false;
                numCucumbers.ReadOnly = true;
            }
        }

        private void chkCarrots_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCarrots.Checked)
            {
                numCarrots.Enabled = true;
                numCarrots.ReadOnly = false;
            }
            else
            {
                numCarrots.Value = 0;
                numCarrots.Enabled = false;
                numCarrots.ReadOnly = true;
            }
        }

        private void chkCelery_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCelery.Checked)
            {
                numCelery.Enabled = true;
                numCelery.ReadOnly = false;
            }
            else
            {
                numCelery.Value = 0;
                numCelery.Enabled = false;
                numCelery.ReadOnly = true;
            }
        }

        private void chkOnions_CheckedChanged(object sender, EventArgs e)
        {
            if (chkOnions.Checked)
            {
                numOnions.Enabled = true;
                numOnions.ReadOnly = false;
            }
            else
            {
                numOnions.Value = 0;
                numOnions.Enabled = false;
                numOnions.ReadOnly = true;
            }
        }

        private void chkSpring_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSpring.Checked)
            {
                numSpring.Enabled = true;
                numSpring.ReadOnly = false;
            }
            else
            {
                numSpring.Value = 0;
                numSpring.Enabled = false;
                numSpring.ReadOnly = true;
            }
        }

        private void chkCoriander_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCoriander.Checked)
            {
                numCoriander.Enabled = true;
                numCoriander.ReadOnly = false;
            }
            else
            {
                numCoriander.Value = 0;
                numCoriander.Enabled = false;
                numCoriander.ReadOnly = true;
            }
        }

        private void chkMeatballs_CheckedChanged(object sender, EventArgs e)
        {
            if (chkMeatballs.Checked)
            {
                numMeatballs.Enabled = true;
                numMeatballs.ReadOnly = false;
            }
            else
            {
                numMeatballs.Value = 0;
                numMeatballs.Enabled = false;
                numMeatballs.ReadOnly = true;
            }
        }

        private void chkBeef_CheckedChanged(object sender, EventArgs e)
        {
            if (chkBeef.Checked)
            {
                numBeef.Enabled = true;
                numBeef.ReadOnly = false;
            }
            else
            {
                numBeef.Value = 0;
                numBeef.Enabled = false;
                numBeef.ReadOnly = true;
            }
        }

        private void chkBacon_CheckedChanged(object sender, EventArgs e)
        {
            if (chkBacon.Checked)
            {
                numBacon.Enabled = true;
                numBacon.ReadOnly = false;
            }
            else
            {
                numBacon.Value = 0;
                numBacon.Enabled = false;
                numBacon.ReadOnly = true;
            }
        }

        private void chkSmokedHam_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSmokedHam.Checked)
            {
                numSmokedHam.Enabled = true;
                numSmokedHam.ReadOnly = false;
            }
            else
            {
                numSmokedHam.Value = 0;
                numSmokedHam.Enabled = false;
                numSmokedHam.ReadOnly = true;
            }
        }

        private void chkFish_CheckedChanged(object sender, EventArgs e)
        {
            if (chkFish.Checked)
            {
                numFish.Enabled = true;
                numFish.ReadOnly = false;
            }
            else
            {
                numFish.Value = 0;
                numFish.Enabled = false;
                numFish.ReadOnly = true;
            }
        }

        private void chkSmokedFish_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSmokedFish.Checked)
            {
                numSmokedFish.Enabled = true;
                numSmokedFish.ReadOnly = false;
            }
            else
            {
                numSmokedFish.Value = 0;
                numSmokedFish.Enabled = false;
                numSmokedFish.ReadOnly = true;
            }
        }

        private void chkRice_CheckedChanged(object sender, EventArgs e)
        {
            if (chkRice.Checked)
            {
                numRice.Enabled = true;
                numRice.ReadOnly = false;
            }
            else
            {
                numRice.Value = 0;
                numRice.Enabled = false;
                numRice.ReadOnly = true;
            }
        }

        private void chkWheat_CheckedChanged(object sender, EventArgs e)
        {
            if (chkWheat.Checked)
            {
                numWheat.Enabled = true;
                numWheat.ReadOnly = false;
            }
            else
            {
                numWheat.Value = 0;
                numWheat.Enabled = false;
                numWheat.ReadOnly = true;
            }
        }

        private void chkCheese_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCheese.Checked)
            {
                numCheese.Enabled = true;
                numCheese.ReadOnly = false;
            }
            else
            {
                numCheese.Value = 0;
                numCheese.Enabled = false;
                numCheese.ReadOnly = true;
            }
        }

        private void chkVodka_CheckedChanged(object sender, EventArgs e)
        {
            if (chkVodka.Checked)
            {
                numVodka.Enabled = true;
                numVodka.ReadOnly = false;
            }
            else
            {
                numVodka.Value = 0;
                numVodka.Enabled = false;
                numVodka.ReadOnly = true;
            }
        }

        private void chkWine_CheckedChanged(object sender, EventArgs e)
        {
            if (chkWine.Checked)
            {
                numWIne.Enabled = true;
                numWIne.ReadOnly = false;
            }
            else
            {
                numWIne.Value = 0;
                numWIne.Enabled = false;
                numWIne.ReadOnly = true;
            }
        }

        private void chkWhiskey_CheckedChanged(object sender, EventArgs e)
        {
            if (chkWhiskey.Checked)
            {
                numWhiskey.Enabled = true;
                numWhiskey.ReadOnly = false;
            }
            else
            {
                numWhiskey.Value = 0;
                numWhiskey.Enabled = false;
                numWhiskey.ReadOnly = true;
            }
        }

        private void chkRum_CheckedChanged(object sender, EventArgs e)
        {
            if (chkRum.Checked)
            {
                numRum.Enabled = true;
                numRum.ReadOnly = false;
            }
            else
            {
                numRum.Value = 0;
                numRum.Enabled = false;
                numRum.ReadOnly = true;
            }
        }

        private void chkGin_CheckedChanged(object sender, EventArgs e)
        {
            if (chkGin.Checked)
            {
                numGin.Enabled = true;
                numGin.ReadOnly = false;
            }
            else
            {
                numGin.Value = 0;
                numGin.Enabled = false;
                numGin.ReadOnly = true;
            }
        }

        private void chkSake_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSake.Checked)
            {
                numSake.Enabled = true;
                numSake.ReadOnly = false;
            }
            else
            {
                numSake.Value = 0;
                numSake.Enabled = false;
                numSake.ReadOnly = true;
            }
        }

        private void chkTequila_CheckedChanged(object sender, EventArgs e)
        {
            if (chkTequila.Checked)
            {
                numTequila.Enabled = true;
                numTequila.ReadOnly = false;
            }
            else
            {
                numTequila.Value = 0;
                numTequila.Enabled = false;
                numTequila.ReadOnly = true;
            }
        }
    }
}
