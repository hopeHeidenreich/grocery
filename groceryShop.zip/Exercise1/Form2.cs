﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Exercise1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            OpenFileDialog OpenFileDialog1 = new OpenFileDialog();

            OpenFileDialog1.Filter = "Text Files|*.rtf";
            OpenFileDialog1.Title = "Open Order Files";

            if (OpenFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtReceipt2.LoadFile(OpenFileDialog1.FileName);
            }
        }
    }
}
