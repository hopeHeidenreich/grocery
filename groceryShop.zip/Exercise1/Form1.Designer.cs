﻿
namespace Exercise1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.order = new System.Windows.Forms.ToolStripMenuItem();
            this.send = new System.Windows.Forms.ToolStripMenuItem();
            this.clear = new System.Windows.Forms.ToolStripMenuItem();
            this.close = new System.Windows.Forms.ToolStripMenuItem();
            this.categories = new System.Windows.Forms.ToolStripMenuItem();
            this.veg = new System.Windows.Forms.ToolStripMenuItem();
            this.broc = new System.Windows.Forms.ToolStripMenuItem();
            this.tomatoes = new System.Windows.Forms.ToolStripMenuItem();
            this.mushrooms = new System.Windows.Forms.ToolStripMenuItem();
            this.beans = new System.Windows.Forms.ToolStripMenuItem();
            this.lettuce = new System.Windows.Forms.ToolStripMenuItem();
            this.grapes = new System.Windows.Forms.ToolStripMenuItem();
            this.cucumber = new System.Windows.Forms.ToolStripMenuItem();
            this.carrots = new System.Windows.Forms.ToolStripMenuItem();
            this.celery = new System.Windows.Forms.ToolStripMenuItem();
            this.onions = new System.Windows.Forms.ToolStripMenuItem();
            this.springO = new System.Windows.Forms.ToolStripMenuItem();
            this.coriander = new System.Windows.Forms.ToolStripMenuItem();
            this.allV = new System.Windows.Forms.ToolStripMenuItem();
            this.meat = new System.Windows.Forms.ToolStripMenuItem();
            this.meatballs = new System.Windows.Forms.ToolStripMenuItem();
            this.beef = new System.Windows.Forms.ToolStripMenuItem();
            this.bacon = new System.Windows.Forms.ToolStripMenuItem();
            this.smokedHam = new System.Windows.Forms.ToolStripMenuItem();
            this.fish = new System.Windows.Forms.ToolStripMenuItem();
            this.smokedFish = new System.Windows.Forms.ToolStripMenuItem();
            this.allM = new System.Windows.Forms.ToolStripMenuItem();
            this.grains = new System.Windows.Forms.ToolStripMenuItem();
            this.rice = new System.Windows.Forms.ToolStripMenuItem();
            this.wheat = new System.Windows.Forms.ToolStripMenuItem();
            this.allG = new System.Windows.Forms.ToolStripMenuItem();
            this.dairy = new System.Windows.Forms.ToolStripMenuItem();
            this.cheese = new System.Windows.Forms.ToolStripMenuItem();
            this.alcohol = new System.Windows.Forms.ToolStripMenuItem();
            this.vodka = new System.Windows.Forms.ToolStripMenuItem();
            this.wine = new System.Windows.Forms.ToolStripMenuItem();
            this.whiskey = new System.Windows.Forms.ToolStripMenuItem();
            this.rum = new System.Windows.Forms.ToolStripMenuItem();
            this.gin = new System.Windows.Forms.ToolStripMenuItem();
            this.sake = new System.Windows.Forms.ToolStripMenuItem();
            this.tequila = new System.Windows.Forms.ToolStripMenuItem();
            this.allA = new System.Windows.Forms.ToolStripMenuItem();
            this.receipt = new System.Windows.Forms.ToolStripMenuItem();
            this.open = new System.Windows.Forms.ToolStripMenuItem();
            this.save = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.new2 = new System.Windows.Forms.ToolStripButton();
            this.cart2 = new System.Windows.Forms.ToolStripButton();
            this.folder2 = new System.Windows.Forms.ToolStripButton();
            this.save2 = new System.Windows.Forms.ToolStripButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.numTequila = new System.Windows.Forms.NumericUpDown();
            this.numSake = new System.Windows.Forms.NumericUpDown();
            this.numGin = new System.Windows.Forms.NumericUpDown();
            this.numRum = new System.Windows.Forms.NumericUpDown();
            this.numWhiskey = new System.Windows.Forms.NumericUpDown();
            this.numWIne = new System.Windows.Forms.NumericUpDown();
            this.numVodka = new System.Windows.Forms.NumericUpDown();
            this.numCheese = new System.Windows.Forms.NumericUpDown();
            this.numWheat = new System.Windows.Forms.NumericUpDown();
            this.numRice = new System.Windows.Forms.NumericUpDown();
            this.numSmokedFish = new System.Windows.Forms.NumericUpDown();
            this.numFish = new System.Windows.Forms.NumericUpDown();
            this.numSmokedHam = new System.Windows.Forms.NumericUpDown();
            this.numBacon = new System.Windows.Forms.NumericUpDown();
            this.numBeef = new System.Windows.Forms.NumericUpDown();
            this.numMeatballs = new System.Windows.Forms.NumericUpDown();
            this.numCoriander = new System.Windows.Forms.NumericUpDown();
            this.numSpring = new System.Windows.Forms.NumericUpDown();
            this.numOnions = new System.Windows.Forms.NumericUpDown();
            this.numCelery = new System.Windows.Forms.NumericUpDown();
            this.numCarrots = new System.Windows.Forms.NumericUpDown();
            this.numCucumbers = new System.Windows.Forms.NumericUpDown();
            this.numGrapes = new System.Windows.Forms.NumericUpDown();
            this.numLettuce = new System.Windows.Forms.NumericUpDown();
            this.numBeans = new System.Windows.Forms.NumericUpDown();
            this.numMushrooms = new System.Windows.Forms.NumericUpDown();
            this.numTomatoes = new System.Windows.Forms.NumericUpDown();
            this.numBroccoli = new System.Windows.Forms.NumericUpDown();
            this.chkTequila = new System.Windows.Forms.CheckBox();
            this.chkSmokedFish = new System.Windows.Forms.CheckBox();
            this.chkSake = new System.Windows.Forms.CheckBox();
            this.chkGin = new System.Windows.Forms.CheckBox();
            this.chkRum = new System.Windows.Forms.CheckBox();
            this.chkWhiskey = new System.Windows.Forms.CheckBox();
            this.chkWine = new System.Windows.Forms.CheckBox();
            this.chkVodka = new System.Windows.Forms.CheckBox();
            this.chkCheese = new System.Windows.Forms.CheckBox();
            this.chkWheat = new System.Windows.Forms.CheckBox();
            this.chkRice = new System.Windows.Forms.CheckBox();
            this.chkFish = new System.Windows.Forms.CheckBox();
            this.chkSmokedHam = new System.Windows.Forms.CheckBox();
            this.chkBacon = new System.Windows.Forms.CheckBox();
            this.chkBeef = new System.Windows.Forms.CheckBox();
            this.chkMeatballs = new System.Windows.Forms.CheckBox();
            this.chkCoriander = new System.Windows.Forms.CheckBox();
            this.chkSpring = new System.Windows.Forms.CheckBox();
            this.chkOnions = new System.Windows.Forms.CheckBox();
            this.chkCelery = new System.Windows.Forms.CheckBox();
            this.chkCarrots = new System.Windows.Forms.CheckBox();
            this.chkCucumbers = new System.Windows.Forms.CheckBox();
            this.chkGrapes = new System.Windows.Forms.CheckBox();
            this.chkLettuce = new System.Windows.Forms.CheckBox();
            this.chkBeans = new System.Windows.Forms.CheckBox();
            this.chkMushrooms = new System.Windows.Forms.CheckBox();
            this.chkTomatoes = new System.Windows.Forms.CheckBox();
            this.chkBroccoli = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtReceipt = new System.Windows.Forms.RichTextBox();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.open4 = new System.Windows.Forms.ToolStripMenuItem();
            this.save4 = new System.Windows.Forms.ToolStripMenuItem();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.txtTax = new System.Windows.Forms.TextBox();
            this.txtSubTotal = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.open3 = new System.Windows.Forms.ToolStripMenuItem();
            this.save3 = new System.Windows.Forms.ToolStripMenuItem();
            this.print3 = new System.Windows.Forms.ToolStripMenuItem();
            this.numericUpDown15 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown16 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown17 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown18 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown19 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown20 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown21 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown22 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown23 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown24 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown25 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown26 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown27 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown28 = new System.Windows.Forms.NumericUpDown();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numTequila)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSake)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numGin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numRum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numWhiskey)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numWIne)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numVodka)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCheese)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numWheat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numRice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSmokedFish)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numFish)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSmokedHam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numBacon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numBeef)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numMeatballs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCoriander)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSpring)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numOnions)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCelery)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCarrots)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCucumbers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numGrapes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numLettuce)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numBeans)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numMushrooms)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTomatoes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numBroccoli)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.contextMenuStrip2.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown28)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.order,
            this.categories,
            this.receipt});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(924, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // order
            // 
            this.order.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.send,
            this.clear,
            this.close});
            this.order.Name = "order";
            this.order.Size = new System.Drawing.Size(49, 20);
            this.order.Text = "Order";
            // 
            // send
            // 
            this.send.Name = "send";
            this.send.Size = new System.Drawing.Size(157, 22);
            this.send.Text = "Send Order";
            this.send.Click += new System.EventHandler(this.send_Click);
            // 
            // clear
            // 
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(157, 22);
            this.clear.Text = "Clear Order";
            this.clear.Click += new System.EventHandler(this.clear_Click);
            // 
            // close
            // 
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(157, 22);
            this.close.Text = "Exit Application";
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // categories
            // 
            this.categories.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.veg,
            this.meat,
            this.grains,
            this.dairy,
            this.alcohol});
            this.categories.Name = "categories";
            this.categories.Size = new System.Drawing.Size(75, 20);
            this.categories.Text = "Categories";
            // 
            // veg
            // 
            this.veg.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.broc,
            this.tomatoes,
            this.mushrooms,
            this.beans,
            this.lettuce,
            this.grapes,
            this.cucumber,
            this.carrots,
            this.celery,
            this.onions,
            this.springO,
            this.coriander,
            this.allV});
            this.veg.Name = "veg";
            this.veg.Size = new System.Drawing.Size(151, 22);
            this.veg.Text = "Vegetables";
            // 
            // broc
            // 
            this.broc.Name = "broc";
            this.broc.Size = new System.Drawing.Size(149, 22);
            this.broc.Text = "Broccoli";
            this.broc.Click += new System.EventHandler(this.broc_Click);
            // 
            // tomatoes
            // 
            this.tomatoes.Name = "tomatoes";
            this.tomatoes.Size = new System.Drawing.Size(149, 22);
            this.tomatoes.Text = "Tomatoes";
            this.tomatoes.Click += new System.EventHandler(this.tomatoes_Click);
            // 
            // mushrooms
            // 
            this.mushrooms.Name = "mushrooms";
            this.mushrooms.Size = new System.Drawing.Size(149, 22);
            this.mushrooms.Text = "Mushrooms";
            this.mushrooms.Click += new System.EventHandler(this.mushrooms_Click);
            // 
            // beans
            // 
            this.beans.Name = "beans";
            this.beans.Size = new System.Drawing.Size(149, 22);
            this.beans.Text = "Beansprouts";
            this.beans.Click += new System.EventHandler(this.beans_Click);
            // 
            // lettuce
            // 
            this.lettuce.Name = "lettuce";
            this.lettuce.Size = new System.Drawing.Size(149, 22);
            this.lettuce.Text = "Lettuce";
            this.lettuce.Click += new System.EventHandler(this.lettuce_Click);
            // 
            // grapes
            // 
            this.grapes.Name = "grapes";
            this.grapes.Size = new System.Drawing.Size(149, 22);
            this.grapes.Text = "Grapes";
            this.grapes.Click += new System.EventHandler(this.grapes_Click);
            // 
            // cucumber
            // 
            this.cucumber.Name = "cucumber";
            this.cucumber.Size = new System.Drawing.Size(149, 22);
            this.cucumber.Text = "Cucumber";
            this.cucumber.Click += new System.EventHandler(this.cucumber_Click);
            // 
            // carrots
            // 
            this.carrots.Name = "carrots";
            this.carrots.Size = new System.Drawing.Size(149, 22);
            this.carrots.Text = "Carrots";
            this.carrots.Click += new System.EventHandler(this.carrots_Click);
            // 
            // celery
            // 
            this.celery.Name = "celery";
            this.celery.Size = new System.Drawing.Size(149, 22);
            this.celery.Text = "Celery";
            this.celery.Click += new System.EventHandler(this.celery_Click);
            // 
            // onions
            // 
            this.onions.Name = "onions";
            this.onions.Size = new System.Drawing.Size(149, 22);
            this.onions.Text = "Onions";
            this.onions.Click += new System.EventHandler(this.onions_Click);
            // 
            // springO
            // 
            this.springO.Name = "springO";
            this.springO.Size = new System.Drawing.Size(149, 22);
            this.springO.Text = "Spring Onions";
            this.springO.Click += new System.EventHandler(this.springO_Click);
            // 
            // coriander
            // 
            this.coriander.Name = "coriander";
            this.coriander.Size = new System.Drawing.Size(149, 22);
            this.coriander.Text = "Coriander";
            this.coriander.Click += new System.EventHandler(this.coriander_Click);
            // 
            // allV
            // 
            this.allV.Name = "allV";
            this.allV.Size = new System.Drawing.Size(149, 22);
            this.allV.Text = "Select All";
            this.allV.Click += new System.EventHandler(this.allV_Click);
            // 
            // meat
            // 
            this.meat.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.meatballs,
            this.beef,
            this.bacon,
            this.smokedHam,
            this.fish,
            this.smokedFish,
            this.allM});
            this.meat.Name = "meat";
            this.meat.Size = new System.Drawing.Size(151, 22);
            this.meat.Text = "Meats";
            // 
            // meatballs
            // 
            this.meatballs.Name = "meatballs";
            this.meatballs.Size = new System.Drawing.Size(146, 22);
            this.meatballs.Text = "Meatballs";
            this.meatballs.Click += new System.EventHandler(this.meatballs_Click);
            // 
            // beef
            // 
            this.beef.Name = "beef";
            this.beef.Size = new System.Drawing.Size(146, 22);
            this.beef.Text = "Beef";
            this.beef.Click += new System.EventHandler(this.beef_Click);
            // 
            // bacon
            // 
            this.bacon.Name = "bacon";
            this.bacon.Size = new System.Drawing.Size(146, 22);
            this.bacon.Text = "Bacon";
            this.bacon.Click += new System.EventHandler(this.bacon_Click);
            // 
            // smokedHam
            // 
            this.smokedHam.Name = "smokedHam";
            this.smokedHam.Size = new System.Drawing.Size(146, 22);
            this.smokedHam.Text = "Smoked Ham";
            this.smokedHam.Click += new System.EventHandler(this.smokedHam_Click);
            // 
            // fish
            // 
            this.fish.Name = "fish";
            this.fish.Size = new System.Drawing.Size(146, 22);
            this.fish.Text = "Fish";
            this.fish.Click += new System.EventHandler(this.fish_Click);
            // 
            // smokedFish
            // 
            this.smokedFish.Name = "smokedFish";
            this.smokedFish.Size = new System.Drawing.Size(146, 22);
            this.smokedFish.Text = "Smoked Fish";
            this.smokedFish.Click += new System.EventHandler(this.smokedFish_Click);
            // 
            // allM
            // 
            this.allM.Name = "allM";
            this.allM.Size = new System.Drawing.Size(146, 22);
            this.allM.Text = "Select All";
            this.allM.Click += new System.EventHandler(this.allM_Click);
            // 
            // grains
            // 
            this.grains.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rice,
            this.wheat,
            this.allG});
            this.grains.Name = "grains";
            this.grains.Size = new System.Drawing.Size(151, 22);
            this.grains.Text = "Grains";
            // 
            // rice
            // 
            this.rice.Name = "rice";
            this.rice.Size = new System.Drawing.Size(122, 22);
            this.rice.Text = "Rice";
            this.rice.Click += new System.EventHandler(this.rice_Click);
            // 
            // wheat
            // 
            this.wheat.Name = "wheat";
            this.wheat.Size = new System.Drawing.Size(122, 22);
            this.wheat.Text = "Wheat";
            this.wheat.Click += new System.EventHandler(this.wheat_Click);
            // 
            // allG
            // 
            this.allG.Name = "allG";
            this.allG.Size = new System.Drawing.Size(122, 22);
            this.allG.Text = "Select All";
            this.allG.Click += new System.EventHandler(this.allG_Click);
            // 
            // dairy
            // 
            this.dairy.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cheese});
            this.dairy.Name = "dairy";
            this.dairy.Size = new System.Drawing.Size(151, 22);
            this.dairy.Text = "Dairy Products";
            // 
            // cheese
            // 
            this.cheese.Name = "cheese";
            this.cheese.Size = new System.Drawing.Size(112, 22);
            this.cheese.Text = "Cheese";
            this.cheese.Click += new System.EventHandler(this.cheese_Click);
            // 
            // alcohol
            // 
            this.alcohol.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.vodka,
            this.wine,
            this.whiskey,
            this.rum,
            this.gin,
            this.sake,
            this.tequila,
            this.allA});
            this.alcohol.Name = "alcohol";
            this.alcohol.Size = new System.Drawing.Size(151, 22);
            this.alcohol.Text = "Alcohol";
            // 
            // vodka
            // 
            this.vodka.Name = "vodka";
            this.vodka.Size = new System.Drawing.Size(122, 22);
            this.vodka.Text = "Vodka";
            this.vodka.Click += new System.EventHandler(this.vodka_Click);
            // 
            // wine
            // 
            this.wine.Name = "wine";
            this.wine.Size = new System.Drawing.Size(122, 22);
            this.wine.Text = "Wine";
            this.wine.Click += new System.EventHandler(this.wine_Click);
            // 
            // whiskey
            // 
            this.whiskey.Name = "whiskey";
            this.whiskey.Size = new System.Drawing.Size(122, 22);
            this.whiskey.Text = "Whiskey";
            this.whiskey.Click += new System.EventHandler(this.whiskey_Click);
            // 
            // rum
            // 
            this.rum.Name = "rum";
            this.rum.Size = new System.Drawing.Size(122, 22);
            this.rum.Text = "Rum";
            this.rum.Click += new System.EventHandler(this.rum_Click);
            // 
            // gin
            // 
            this.gin.Name = "gin";
            this.gin.Size = new System.Drawing.Size(122, 22);
            this.gin.Text = "Gin";
            this.gin.Click += new System.EventHandler(this.gin_Click);
            // 
            // sake
            // 
            this.sake.Name = "sake";
            this.sake.Size = new System.Drawing.Size(122, 22);
            this.sake.Text = "Sake";
            this.sake.Click += new System.EventHandler(this.sake_Click);
            // 
            // tequila
            // 
            this.tequila.Name = "tequila";
            this.tequila.Size = new System.Drawing.Size(122, 22);
            this.tequila.Text = "Tequila";
            this.tequila.Click += new System.EventHandler(this.tequila_Click);
            // 
            // allA
            // 
            this.allA.Name = "allA";
            this.allA.Size = new System.Drawing.Size(122, 22);
            this.allA.Text = "Select All";
            this.allA.Click += new System.EventHandler(this.allA_Click);
            // 
            // receipt
            // 
            this.receipt.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.open,
            this.save});
            this.receipt.Name = "receipt";
            this.receipt.Size = new System.Drawing.Size(58, 20);
            this.receipt.Text = "Receipt";
            // 
            // open
            // 
            this.open.Name = "open";
            this.open.Size = new System.Drawing.Size(103, 22);
            this.open.Text = "Open";
            this.open.Click += new System.EventHandler(this.open1_Click);
            // 
            // save
            // 
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(103, 22);
            this.save.Text = "Save";
            this.save.Click += new System.EventHandler(this.save1_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(214)))), ((int)(((byte)(243)))));
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.new2,
            this.cart2,
            this.folder2,
            this.save2});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(924, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // new2
            // 
            this.new2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.new2.Image = ((System.Drawing.Image)(resources.GetObject("new2.Image")));
            this.new2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.new2.Name = "new2";
            this.new2.Size = new System.Drawing.Size(23, 22);
            this.new2.Text = "New Form";
            this.new2.Click += new System.EventHandler(this.new2_Click);
            // 
            // cart2
            // 
            this.cart2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.cart2.Image = ((System.Drawing.Image)(resources.GetObject("cart2.Image")));
            this.cart2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cart2.Name = "cart2";
            this.cart2.Size = new System.Drawing.Size(23, 22);
            this.cart2.Text = "Order";
            this.cart2.Click += new System.EventHandler(this.cart2_Click);
            // 
            // folder2
            // 
            this.folder2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.folder2.Image = ((System.Drawing.Image)(resources.GetObject("folder2.Image")));
            this.folder2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.folder2.Name = "folder2";
            this.folder2.Size = new System.Drawing.Size(23, 22);
            this.folder2.Text = "Open";
            this.folder2.Click += new System.EventHandler(this.folder2_Click);
            // 
            // save2
            // 
            this.save2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.save2.Image = ((System.Drawing.Image)(resources.GetObject("save2.Image")));
            this.save2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.save2.Name = "save2";
            this.save2.Size = new System.Drawing.Size(23, 22);
            this.save2.Text = "Save";
            this.save2.Click += new System.EventHandler(this.save2_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.numTequila);
            this.groupBox1.Controls.Add(this.numSake);
            this.groupBox1.Controls.Add(this.numGin);
            this.groupBox1.Controls.Add(this.numRum);
            this.groupBox1.Controls.Add(this.numWhiskey);
            this.groupBox1.Controls.Add(this.numWIne);
            this.groupBox1.Controls.Add(this.numVodka);
            this.groupBox1.Controls.Add(this.numCheese);
            this.groupBox1.Controls.Add(this.numWheat);
            this.groupBox1.Controls.Add(this.numRice);
            this.groupBox1.Controls.Add(this.numSmokedFish);
            this.groupBox1.Controls.Add(this.numFish);
            this.groupBox1.Controls.Add(this.numSmokedHam);
            this.groupBox1.Controls.Add(this.numBacon);
            this.groupBox1.Controls.Add(this.numBeef);
            this.groupBox1.Controls.Add(this.numMeatballs);
            this.groupBox1.Controls.Add(this.numCoriander);
            this.groupBox1.Controls.Add(this.numSpring);
            this.groupBox1.Controls.Add(this.numOnions);
            this.groupBox1.Controls.Add(this.numCelery);
            this.groupBox1.Controls.Add(this.numCarrots);
            this.groupBox1.Controls.Add(this.numCucumbers);
            this.groupBox1.Controls.Add(this.numGrapes);
            this.groupBox1.Controls.Add(this.numLettuce);
            this.groupBox1.Controls.Add(this.numBeans);
            this.groupBox1.Controls.Add(this.numMushrooms);
            this.groupBox1.Controls.Add(this.numTomatoes);
            this.groupBox1.Controls.Add(this.numBroccoli);
            this.groupBox1.Controls.Add(this.chkTequila);
            this.groupBox1.Controls.Add(this.chkSmokedFish);
            this.groupBox1.Controls.Add(this.chkSake);
            this.groupBox1.Controls.Add(this.chkGin);
            this.groupBox1.Controls.Add(this.chkRum);
            this.groupBox1.Controls.Add(this.chkWhiskey);
            this.groupBox1.Controls.Add(this.chkWine);
            this.groupBox1.Controls.Add(this.chkVodka);
            this.groupBox1.Controls.Add(this.chkCheese);
            this.groupBox1.Controls.Add(this.chkWheat);
            this.groupBox1.Controls.Add(this.chkRice);
            this.groupBox1.Controls.Add(this.chkFish);
            this.groupBox1.Controls.Add(this.chkSmokedHam);
            this.groupBox1.Controls.Add(this.chkBacon);
            this.groupBox1.Controls.Add(this.chkBeef);
            this.groupBox1.Controls.Add(this.chkMeatballs);
            this.groupBox1.Controls.Add(this.chkCoriander);
            this.groupBox1.Controls.Add(this.chkSpring);
            this.groupBox1.Controls.Add(this.chkOnions);
            this.groupBox1.Controls.Add(this.chkCelery);
            this.groupBox1.Controls.Add(this.chkCarrots);
            this.groupBox1.Controls.Add(this.chkCucumbers);
            this.groupBox1.Controls.Add(this.chkGrapes);
            this.groupBox1.Controls.Add(this.chkLettuce);
            this.groupBox1.Controls.Add(this.chkBeans);
            this.groupBox1.Controls.Add(this.chkMushrooms);
            this.groupBox1.Controls.Add(this.chkTomatoes);
            this.groupBox1.Controls.Add(this.chkBroccoli);
            this.groupBox1.Location = new System.Drawing.Point(12, 52);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(567, 468);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Grocery Selection";
            // 
            // numTequila
            // 
            this.numTequila.Enabled = false;
            this.numTequila.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numTequila.Location = new System.Drawing.Point(511, 425);
            this.numTequila.Name = "numTequila";
            this.numTequila.ReadOnly = true;
            this.numTequila.Size = new System.Drawing.Size(50, 27);
            this.numTequila.TabIndex = 55;
            // 
            // numSake
            // 
            this.numSake.Enabled = false;
            this.numSake.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numSake.Location = new System.Drawing.Point(511, 394);
            this.numSake.Name = "numSake";
            this.numSake.ReadOnly = true;
            this.numSake.Size = new System.Drawing.Size(50, 27);
            this.numSake.TabIndex = 54;
            // 
            // numGin
            // 
            this.numGin.Enabled = false;
            this.numGin.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numGin.Location = new System.Drawing.Point(511, 363);
            this.numGin.Name = "numGin";
            this.numGin.ReadOnly = true;
            this.numGin.Size = new System.Drawing.Size(50, 27);
            this.numGin.TabIndex = 53;
            // 
            // numRum
            // 
            this.numRum.Enabled = false;
            this.numRum.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numRum.Location = new System.Drawing.Point(511, 332);
            this.numRum.Name = "numRum";
            this.numRum.ReadOnly = true;
            this.numRum.Size = new System.Drawing.Size(50, 27);
            this.numRum.TabIndex = 52;
            // 
            // numWhiskey
            // 
            this.numWhiskey.Enabled = false;
            this.numWhiskey.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numWhiskey.Location = new System.Drawing.Point(511, 301);
            this.numWhiskey.Name = "numWhiskey";
            this.numWhiskey.ReadOnly = true;
            this.numWhiskey.Size = new System.Drawing.Size(50, 27);
            this.numWhiskey.TabIndex = 51;
            // 
            // numWIne
            // 
            this.numWIne.Enabled = false;
            this.numWIne.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numWIne.Location = new System.Drawing.Point(511, 270);
            this.numWIne.Name = "numWIne";
            this.numWIne.ReadOnly = true;
            this.numWIne.Size = new System.Drawing.Size(50, 27);
            this.numWIne.TabIndex = 50;
            // 
            // numVodka
            // 
            this.numVodka.Enabled = false;
            this.numVodka.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numVodka.Location = new System.Drawing.Point(511, 239);
            this.numVodka.Name = "numVodka";
            this.numVodka.ReadOnly = true;
            this.numVodka.Size = new System.Drawing.Size(50, 27);
            this.numVodka.TabIndex = 49;
            // 
            // numCheese
            // 
            this.numCheese.Enabled = false;
            this.numCheese.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numCheese.Location = new System.Drawing.Point(511, 208);
            this.numCheese.Name = "numCheese";
            this.numCheese.ReadOnly = true;
            this.numCheese.Size = new System.Drawing.Size(50, 27);
            this.numCheese.TabIndex = 48;
            // 
            // numWheat
            // 
            this.numWheat.Enabled = false;
            this.numWheat.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numWheat.Location = new System.Drawing.Point(511, 177);
            this.numWheat.Name = "numWheat";
            this.numWheat.ReadOnly = true;
            this.numWheat.Size = new System.Drawing.Size(50, 27);
            this.numWheat.TabIndex = 47;
            // 
            // numRice
            // 
            this.numRice.Enabled = false;
            this.numRice.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numRice.Location = new System.Drawing.Point(511, 146);
            this.numRice.Name = "numRice";
            this.numRice.ReadOnly = true;
            this.numRice.Size = new System.Drawing.Size(50, 27);
            this.numRice.TabIndex = 46;
            // 
            // numSmokedFish
            // 
            this.numSmokedFish.Enabled = false;
            this.numSmokedFish.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numSmokedFish.Location = new System.Drawing.Point(511, 115);
            this.numSmokedFish.Name = "numSmokedFish";
            this.numSmokedFish.ReadOnly = true;
            this.numSmokedFish.Size = new System.Drawing.Size(50, 27);
            this.numSmokedFish.TabIndex = 45;
            // 
            // numFish
            // 
            this.numFish.Enabled = false;
            this.numFish.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numFish.Location = new System.Drawing.Point(511, 84);
            this.numFish.Name = "numFish";
            this.numFish.ReadOnly = true;
            this.numFish.Size = new System.Drawing.Size(50, 27);
            this.numFish.TabIndex = 44;
            // 
            // numSmokedHam
            // 
            this.numSmokedHam.Enabled = false;
            this.numSmokedHam.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numSmokedHam.Location = new System.Drawing.Point(511, 53);
            this.numSmokedHam.Name = "numSmokedHam";
            this.numSmokedHam.ReadOnly = true;
            this.numSmokedHam.Size = new System.Drawing.Size(50, 27);
            this.numSmokedHam.TabIndex = 43;
            // 
            // numBacon
            // 
            this.numBacon.Enabled = false;
            this.numBacon.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numBacon.Location = new System.Drawing.Point(511, 22);
            this.numBacon.Name = "numBacon";
            this.numBacon.ReadOnly = true;
            this.numBacon.Size = new System.Drawing.Size(50, 27);
            this.numBacon.TabIndex = 42;
            // 
            // numBeef
            // 
            this.numBeef.Enabled = false;
            this.numBeef.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numBeef.Location = new System.Drawing.Point(251, 425);
            this.numBeef.Name = "numBeef";
            this.numBeef.ReadOnly = true;
            this.numBeef.Size = new System.Drawing.Size(50, 27);
            this.numBeef.TabIndex = 41;
            // 
            // numMeatballs
            // 
            this.numMeatballs.Enabled = false;
            this.numMeatballs.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numMeatballs.Location = new System.Drawing.Point(251, 394);
            this.numMeatballs.Name = "numMeatballs";
            this.numMeatballs.ReadOnly = true;
            this.numMeatballs.Size = new System.Drawing.Size(50, 27);
            this.numMeatballs.TabIndex = 40;
            // 
            // numCoriander
            // 
            this.numCoriander.Enabled = false;
            this.numCoriander.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numCoriander.Location = new System.Drawing.Point(251, 363);
            this.numCoriander.Name = "numCoriander";
            this.numCoriander.ReadOnly = true;
            this.numCoriander.Size = new System.Drawing.Size(50, 27);
            this.numCoriander.TabIndex = 39;
            // 
            // numSpring
            // 
            this.numSpring.Enabled = false;
            this.numSpring.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numSpring.Location = new System.Drawing.Point(251, 332);
            this.numSpring.Name = "numSpring";
            this.numSpring.ReadOnly = true;
            this.numSpring.Size = new System.Drawing.Size(50, 27);
            this.numSpring.TabIndex = 38;
            // 
            // numOnions
            // 
            this.numOnions.Enabled = false;
            this.numOnions.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numOnions.Location = new System.Drawing.Point(251, 301);
            this.numOnions.Name = "numOnions";
            this.numOnions.ReadOnly = true;
            this.numOnions.Size = new System.Drawing.Size(50, 27);
            this.numOnions.TabIndex = 37;
            // 
            // numCelery
            // 
            this.numCelery.Enabled = false;
            this.numCelery.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numCelery.Location = new System.Drawing.Point(251, 270);
            this.numCelery.Name = "numCelery";
            this.numCelery.ReadOnly = true;
            this.numCelery.Size = new System.Drawing.Size(50, 27);
            this.numCelery.TabIndex = 36;
            // 
            // numCarrots
            // 
            this.numCarrots.Enabled = false;
            this.numCarrots.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numCarrots.Location = new System.Drawing.Point(251, 239);
            this.numCarrots.Name = "numCarrots";
            this.numCarrots.ReadOnly = true;
            this.numCarrots.Size = new System.Drawing.Size(50, 27);
            this.numCarrots.TabIndex = 35;
            // 
            // numCucumbers
            // 
            this.numCucumbers.Enabled = false;
            this.numCucumbers.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numCucumbers.Location = new System.Drawing.Point(251, 208);
            this.numCucumbers.Name = "numCucumbers";
            this.numCucumbers.ReadOnly = true;
            this.numCucumbers.Size = new System.Drawing.Size(50, 27);
            this.numCucumbers.TabIndex = 34;
            // 
            // numGrapes
            // 
            this.numGrapes.Enabled = false;
            this.numGrapes.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numGrapes.Location = new System.Drawing.Point(251, 177);
            this.numGrapes.Name = "numGrapes";
            this.numGrapes.ReadOnly = true;
            this.numGrapes.Size = new System.Drawing.Size(50, 27);
            this.numGrapes.TabIndex = 33;
            // 
            // numLettuce
            // 
            this.numLettuce.Enabled = false;
            this.numLettuce.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numLettuce.Location = new System.Drawing.Point(251, 146);
            this.numLettuce.Name = "numLettuce";
            this.numLettuce.ReadOnly = true;
            this.numLettuce.Size = new System.Drawing.Size(50, 27);
            this.numLettuce.TabIndex = 32;
            // 
            // numBeans
            // 
            this.numBeans.Enabled = false;
            this.numBeans.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numBeans.Location = new System.Drawing.Point(251, 115);
            this.numBeans.Name = "numBeans";
            this.numBeans.ReadOnly = true;
            this.numBeans.Size = new System.Drawing.Size(50, 27);
            this.numBeans.TabIndex = 31;
            // 
            // numMushrooms
            // 
            this.numMushrooms.Enabled = false;
            this.numMushrooms.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numMushrooms.Location = new System.Drawing.Point(251, 84);
            this.numMushrooms.Name = "numMushrooms";
            this.numMushrooms.ReadOnly = true;
            this.numMushrooms.Size = new System.Drawing.Size(50, 27);
            this.numMushrooms.TabIndex = 30;
            // 
            // numTomatoes
            // 
            this.numTomatoes.Enabled = false;
            this.numTomatoes.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numTomatoes.Location = new System.Drawing.Point(251, 53);
            this.numTomatoes.Name = "numTomatoes";
            this.numTomatoes.ReadOnly = true;
            this.numTomatoes.Size = new System.Drawing.Size(50, 27);
            this.numTomatoes.TabIndex = 29;
            // 
            // numBroccoli
            // 
            this.numBroccoli.Enabled = false;
            this.numBroccoli.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numBroccoli.Location = new System.Drawing.Point(251, 22);
            this.numBroccoli.Name = "numBroccoli";
            this.numBroccoli.ReadOnly = true;
            this.numBroccoli.Size = new System.Drawing.Size(50, 27);
            this.numBroccoli.TabIndex = 28;
            // 
            // chkTequila
            // 
            this.chkTequila.AutoSize = true;
            this.chkTequila.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.chkTequila.Location = new System.Drawing.Point(316, 425);
            this.chkTequila.Name = "chkTequila";
            this.chkTequila.Size = new System.Drawing.Size(77, 25);
            this.chkTequila.TabIndex = 27;
            this.chkTequila.Text = "Tequila";
            this.chkTequila.UseVisualStyleBackColor = true;
            this.chkTequila.CheckedChanged += new System.EventHandler(this.chkTequila_CheckedChanged);
            // 
            // chkSmokedFish
            // 
            this.chkSmokedFish.AutoSize = true;
            this.chkSmokedFish.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.chkSmokedFish.Location = new System.Drawing.Point(316, 115);
            this.chkSmokedFish.Name = "chkSmokedFish";
            this.chkSmokedFish.Size = new System.Drawing.Size(118, 25);
            this.chkSmokedFish.TabIndex = 26;
            this.chkSmokedFish.Text = "Smoked Fish";
            this.chkSmokedFish.UseVisualStyleBackColor = true;
            this.chkSmokedFish.CheckedChanged += new System.EventHandler(this.chkSmokedFish_CheckedChanged);
            // 
            // chkSake
            // 
            this.chkSake.AutoSize = true;
            this.chkSake.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.chkSake.Location = new System.Drawing.Point(316, 394);
            this.chkSake.Name = "chkSake";
            this.chkSake.Size = new System.Drawing.Size(62, 25);
            this.chkSake.TabIndex = 25;
            this.chkSake.Text = "Sake";
            this.chkSake.UseVisualStyleBackColor = true;
            this.chkSake.CheckedChanged += new System.EventHandler(this.chkSake_CheckedChanged);
            // 
            // chkGin
            // 
            this.chkGin.AutoSize = true;
            this.chkGin.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.chkGin.Location = new System.Drawing.Point(316, 363);
            this.chkGin.Name = "chkGin";
            this.chkGin.Size = new System.Drawing.Size(53, 25);
            this.chkGin.TabIndex = 24;
            this.chkGin.Text = "Gin";
            this.chkGin.UseVisualStyleBackColor = true;
            this.chkGin.CheckedChanged += new System.EventHandler(this.chkGin_CheckedChanged);
            // 
            // chkRum
            // 
            this.chkRum.AutoSize = true;
            this.chkRum.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.chkRum.Location = new System.Drawing.Point(316, 332);
            this.chkRum.Name = "chkRum";
            this.chkRum.Size = new System.Drawing.Size(62, 25);
            this.chkRum.TabIndex = 23;
            this.chkRum.Text = "Rum";
            this.chkRum.UseVisualStyleBackColor = true;
            this.chkRum.CheckedChanged += new System.EventHandler(this.chkRum_CheckedChanged);
            // 
            // chkWhiskey
            // 
            this.chkWhiskey.AutoSize = true;
            this.chkWhiskey.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.chkWhiskey.Location = new System.Drawing.Point(316, 301);
            this.chkWhiskey.Name = "chkWhiskey";
            this.chkWhiskey.Size = new System.Drawing.Size(88, 25);
            this.chkWhiskey.TabIndex = 22;
            this.chkWhiskey.Text = "Whiskey";
            this.chkWhiskey.UseVisualStyleBackColor = true;
            this.chkWhiskey.CheckedChanged += new System.EventHandler(this.chkWhiskey_CheckedChanged);
            // 
            // chkWine
            // 
            this.chkWine.AutoSize = true;
            this.chkWine.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.chkWine.Location = new System.Drawing.Point(316, 270);
            this.chkWine.Name = "chkWine";
            this.chkWine.Size = new System.Drawing.Size(65, 25);
            this.chkWine.TabIndex = 21;
            this.chkWine.Text = "Wine";
            this.chkWine.UseVisualStyleBackColor = true;
            this.chkWine.CheckedChanged += new System.EventHandler(this.chkWine_CheckedChanged);
            // 
            // chkVodka
            // 
            this.chkVodka.AutoSize = true;
            this.chkVodka.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.chkVodka.Location = new System.Drawing.Point(316, 239);
            this.chkVodka.Name = "chkVodka";
            this.chkVodka.Size = new System.Drawing.Size(72, 25);
            this.chkVodka.TabIndex = 20;
            this.chkVodka.Text = "Vodka";
            this.chkVodka.UseVisualStyleBackColor = true;
            this.chkVodka.CheckedChanged += new System.EventHandler(this.chkVodka_CheckedChanged);
            // 
            // chkCheese
            // 
            this.chkCheese.AutoSize = true;
            this.chkCheese.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.chkCheese.Location = new System.Drawing.Point(316, 208);
            this.chkCheese.Name = "chkCheese";
            this.chkCheese.Size = new System.Drawing.Size(79, 25);
            this.chkCheese.TabIndex = 19;
            this.chkCheese.Text = "Cheese";
            this.chkCheese.UseVisualStyleBackColor = true;
            this.chkCheese.CheckedChanged += new System.EventHandler(this.chkCheese_CheckedChanged);
            // 
            // chkWheat
            // 
            this.chkWheat.AutoSize = true;
            this.chkWheat.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.chkWheat.Location = new System.Drawing.Point(316, 177);
            this.chkWheat.Name = "chkWheat";
            this.chkWheat.Size = new System.Drawing.Size(74, 25);
            this.chkWheat.TabIndex = 18;
            this.chkWheat.Text = "Wheat";
            this.chkWheat.UseVisualStyleBackColor = true;
            this.chkWheat.CheckedChanged += new System.EventHandler(this.chkWheat_CheckedChanged);
            // 
            // chkRice
            // 
            this.chkRice.AutoSize = true;
            this.chkRice.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.chkRice.Location = new System.Drawing.Point(316, 146);
            this.chkRice.Name = "chkRice";
            this.chkRice.Size = new System.Drawing.Size(58, 25);
            this.chkRice.TabIndex = 17;
            this.chkRice.Text = "Rice";
            this.chkRice.UseVisualStyleBackColor = true;
            this.chkRice.CheckedChanged += new System.EventHandler(this.chkRice_CheckedChanged);
            // 
            // chkFish
            // 
            this.chkFish.AutoSize = true;
            this.chkFish.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.chkFish.Location = new System.Drawing.Point(316, 84);
            this.chkFish.Name = "chkFish";
            this.chkFish.Size = new System.Drawing.Size(57, 25);
            this.chkFish.TabIndex = 16;
            this.chkFish.Text = "Fish";
            this.chkFish.UseVisualStyleBackColor = true;
            this.chkFish.CheckedChanged += new System.EventHandler(this.chkFish_CheckedChanged);
            // 
            // chkSmokedHam
            // 
            this.chkSmokedHam.AutoSize = true;
            this.chkSmokedHam.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.chkSmokedHam.Location = new System.Drawing.Point(316, 53);
            this.chkSmokedHam.Name = "chkSmokedHam";
            this.chkSmokedHam.Size = new System.Drawing.Size(123, 25);
            this.chkSmokedHam.TabIndex = 15;
            this.chkSmokedHam.Text = "Smoked Ham";
            this.chkSmokedHam.UseVisualStyleBackColor = true;
            this.chkSmokedHam.CheckedChanged += new System.EventHandler(this.chkSmokedHam_CheckedChanged);
            // 
            // chkBacon
            // 
            this.chkBacon.AutoSize = true;
            this.chkBacon.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.chkBacon.Location = new System.Drawing.Point(316, 22);
            this.chkBacon.Name = "chkBacon";
            this.chkBacon.Size = new System.Drawing.Size(71, 25);
            this.chkBacon.TabIndex = 14;
            this.chkBacon.Text = "Bacon";
            this.chkBacon.UseVisualStyleBackColor = true;
            this.chkBacon.CheckedChanged += new System.EventHandler(this.chkBacon_CheckedChanged);
            // 
            // chkBeef
            // 
            this.chkBeef.AutoSize = true;
            this.chkBeef.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.chkBeef.Location = new System.Drawing.Point(6, 425);
            this.chkBeef.Name = "chkBeef";
            this.chkBeef.Size = new System.Drawing.Size(59, 25);
            this.chkBeef.TabIndex = 13;
            this.chkBeef.Text = "Beef";
            this.chkBeef.UseVisualStyleBackColor = true;
            this.chkBeef.CheckedChanged += new System.EventHandler(this.chkBeef_CheckedChanged);
            // 
            // chkMeatballs
            // 
            this.chkMeatballs.AutoSize = true;
            this.chkMeatballs.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.chkMeatballs.Location = new System.Drawing.Point(6, 394);
            this.chkMeatballs.Name = "chkMeatballs";
            this.chkMeatballs.Size = new System.Drawing.Size(96, 25);
            this.chkMeatballs.TabIndex = 12;
            this.chkMeatballs.Text = "Meatballs";
            this.chkMeatballs.UseVisualStyleBackColor = true;
            this.chkMeatballs.CheckedChanged += new System.EventHandler(this.chkMeatballs_CheckedChanged);
            // 
            // chkCoriander
            // 
            this.chkCoriander.AutoSize = true;
            this.chkCoriander.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.chkCoriander.Location = new System.Drawing.Point(6, 363);
            this.chkCoriander.Name = "chkCoriander";
            this.chkCoriander.Size = new System.Drawing.Size(98, 25);
            this.chkCoriander.TabIndex = 11;
            this.chkCoriander.Text = "Coriander";
            this.chkCoriander.UseVisualStyleBackColor = true;
            this.chkCoriander.CheckedChanged += new System.EventHandler(this.chkCoriander_CheckedChanged);
            // 
            // chkSpring
            // 
            this.chkSpring.AutoSize = true;
            this.chkSpring.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.chkSpring.Location = new System.Drawing.Point(6, 332);
            this.chkSpring.Name = "chkSpring";
            this.chkSpring.Size = new System.Drawing.Size(129, 25);
            this.chkSpring.TabIndex = 10;
            this.chkSpring.Text = "Spring Onions";
            this.chkSpring.UseVisualStyleBackColor = true;
            this.chkSpring.CheckedChanged += new System.EventHandler(this.chkSpring_CheckedChanged);
            // 
            // chkOnions
            // 
            this.chkOnions.AutoSize = true;
            this.chkOnions.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.chkOnions.Location = new System.Drawing.Point(6, 301);
            this.chkOnions.Name = "chkOnions";
            this.chkOnions.Size = new System.Drawing.Size(79, 25);
            this.chkOnions.TabIndex = 9;
            this.chkOnions.Text = "Onions";
            this.chkOnions.UseVisualStyleBackColor = true;
            this.chkOnions.CheckedChanged += new System.EventHandler(this.chkOnions_CheckedChanged);
            // 
            // chkCelery
            // 
            this.chkCelery.AutoSize = true;
            this.chkCelery.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.chkCelery.Location = new System.Drawing.Point(6, 270);
            this.chkCelery.Name = "chkCelery";
            this.chkCelery.Size = new System.Drawing.Size(73, 25);
            this.chkCelery.TabIndex = 8;
            this.chkCelery.Text = "Celery";
            this.chkCelery.UseVisualStyleBackColor = true;
            this.chkCelery.CheckedChanged += new System.EventHandler(this.chkCelery_CheckedChanged);
            // 
            // chkCarrots
            // 
            this.chkCarrots.AutoSize = true;
            this.chkCarrots.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.chkCarrots.Location = new System.Drawing.Point(6, 239);
            this.chkCarrots.Name = "chkCarrots";
            this.chkCarrots.Size = new System.Drawing.Size(80, 25);
            this.chkCarrots.TabIndex = 7;
            this.chkCarrots.Text = "Carrots";
            this.chkCarrots.UseVisualStyleBackColor = true;
            this.chkCarrots.CheckedChanged += new System.EventHandler(this.chkCarrots_CheckedChanged);
            // 
            // chkCucumbers
            // 
            this.chkCucumbers.AutoSize = true;
            this.chkCucumbers.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.chkCucumbers.Location = new System.Drawing.Point(6, 208);
            this.chkCucumbers.Name = "chkCucumbers";
            this.chkCucumbers.Size = new System.Drawing.Size(108, 25);
            this.chkCucumbers.TabIndex = 6;
            this.chkCucumbers.Text = "Cucumbers";
            this.chkCucumbers.UseVisualStyleBackColor = true;
            this.chkCucumbers.CheckedChanged += new System.EventHandler(this.chkCucumbers_CheckedChanged);
            // 
            // chkGrapes
            // 
            this.chkGrapes.AutoSize = true;
            this.chkGrapes.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.chkGrapes.Location = new System.Drawing.Point(6, 177);
            this.chkGrapes.Name = "chkGrapes";
            this.chkGrapes.Size = new System.Drawing.Size(78, 25);
            this.chkGrapes.TabIndex = 5;
            this.chkGrapes.Text = "Grapes";
            this.chkGrapes.UseVisualStyleBackColor = true;
            this.chkGrapes.CheckedChanged += new System.EventHandler(this.chkGrapes_CheckedChanged);
            // 
            // chkLettuce
            // 
            this.chkLettuce.AutoSize = true;
            this.chkLettuce.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.chkLettuce.Location = new System.Drawing.Point(6, 146);
            this.chkLettuce.Name = "chkLettuce";
            this.chkLettuce.Size = new System.Drawing.Size(79, 25);
            this.chkLettuce.TabIndex = 4;
            this.chkLettuce.Text = "Lettuce";
            this.chkLettuce.UseVisualStyleBackColor = true;
            this.chkLettuce.CheckedChanged += new System.EventHandler(this.chkLettuce_CheckedChanged);
            // 
            // chkBeans
            // 
            this.chkBeans.AutoSize = true;
            this.chkBeans.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.chkBeans.Location = new System.Drawing.Point(6, 115);
            this.chkBeans.Name = "chkBeans";
            this.chkBeans.Size = new System.Drawing.Size(115, 25);
            this.chkBeans.TabIndex = 3;
            this.chkBeans.Text = "Beansprouts";
            this.chkBeans.UseVisualStyleBackColor = true;
            this.chkBeans.CheckedChanged += new System.EventHandler(this.chkBeans_CheckedChanged);
            // 
            // chkMushrooms
            // 
            this.chkMushrooms.AutoSize = true;
            this.chkMushrooms.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.chkMushrooms.Location = new System.Drawing.Point(6, 84);
            this.chkMushrooms.Name = "chkMushrooms";
            this.chkMushrooms.Size = new System.Drawing.Size(113, 25);
            this.chkMushrooms.TabIndex = 2;
            this.chkMushrooms.Text = "Mushrooms";
            this.chkMushrooms.UseVisualStyleBackColor = true;
            this.chkMushrooms.CheckedChanged += new System.EventHandler(this.chkMushrooms_CheckedChanged);
            // 
            // chkTomatoes
            // 
            this.chkTomatoes.AutoSize = true;
            this.chkTomatoes.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.chkTomatoes.Location = new System.Drawing.Point(6, 53);
            this.chkTomatoes.Name = "chkTomatoes";
            this.chkTomatoes.Size = new System.Drawing.Size(95, 25);
            this.chkTomatoes.TabIndex = 1;
            this.chkTomatoes.Text = "Tomatoes";
            this.chkTomatoes.UseVisualStyleBackColor = true;
            this.chkTomatoes.CheckedChanged += new System.EventHandler(this.chkTomatoes_CheckedChanged);
            // 
            // chkBroccoli
            // 
            this.chkBroccoli.AutoSize = true;
            this.chkBroccoli.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.chkBroccoli.Location = new System.Drawing.Point(6, 22);
            this.chkBroccoli.Name = "chkBroccoli";
            this.chkBroccoli.Size = new System.Drawing.Size(84, 25);
            this.chkBroccoli.TabIndex = 0;
            this.chkBroccoli.Text = "Broccoli";
            this.chkBroccoli.UseVisualStyleBackColor = true;
            this.chkBroccoli.CheckedChanged += new System.EventHandler(this.chkBroccoli_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtReceipt);
            this.groupBox2.Controls.Add(this.txtTotal);
            this.groupBox2.Controls.Add(this.txtTax);
            this.groupBox2.Controls.Add(this.txtSubTotal);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(585, 52);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(325, 468);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Checkout Information";
            // 
            // txtReceipt
            // 
            this.txtReceipt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(214)))), ((int)(((byte)(243)))));
            this.txtReceipt.ContextMenuStrip = this.contextMenuStrip2;
            this.txtReceipt.Location = new System.Drawing.Point(9, 142);
            this.txtReceipt.Name = "txtReceipt";
            this.txtReceipt.Size = new System.Drawing.Size(306, 309);
            this.txtReceipt.TabIndex = 6;
            this.txtReceipt.Text = "";
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.open4,
            this.save4});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(146, 48);
            // 
            // open4
            // 
            this.open4.Image = ((System.Drawing.Image)(resources.GetObject("open4.Image")));
            this.open4.Name = "open4";
            this.open4.Size = new System.Drawing.Size(145, 22);
            this.open4.Text = "Open Receipt";
            this.open4.Click += new System.EventHandler(this.open4_Click);
            // 
            // save4
            // 
            this.save4.Image = ((System.Drawing.Image)(resources.GetObject("save4.Image")));
            this.save4.Name = "save4";
            this.save4.Size = new System.Drawing.Size(145, 22);
            this.save4.Text = "Save Receipt";
            this.save4.Click += new System.EventHandler(this.save4_Click);
            // 
            // txtTotal
            // 
            this.txtTotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(214)))), ((int)(((byte)(243)))));
            this.txtTotal.Location = new System.Drawing.Point(168, 93);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.ReadOnly = true;
            this.txtTotal.Size = new System.Drawing.Size(110, 23);
            this.txtTotal.TabIndex = 5;
            this.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTax
            // 
            this.txtTax.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(214)))), ((int)(((byte)(243)))));
            this.txtTax.Location = new System.Drawing.Point(168, 62);
            this.txtTax.Name = "txtTax";
            this.txtTax.ReadOnly = true;
            this.txtTax.Size = new System.Drawing.Size(110, 23);
            this.txtTax.TabIndex = 4;
            this.txtTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtSubTotal
            // 
            this.txtSubTotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(214)))), ((int)(((byte)(243)))));
            this.txtSubTotal.Location = new System.Drawing.Point(168, 31);
            this.txtSubTotal.Name = "txtSubTotal";
            this.txtSubTotal.ReadOnly = true;
            this.txtSubTotal.Size = new System.Drawing.Size(110, 23);
            this.txtSubTotal.TabIndex = 3;
            this.txtSubTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(52, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Total:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(52, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tax:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(52, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Sub-Total:";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.open3,
            this.save3,
            this.print3});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(146, 70);
            // 
            // open3
            // 
            this.open3.Image = ((System.Drawing.Image)(resources.GetObject("open3.Image")));
            this.open3.Name = "open3";
            this.open3.Size = new System.Drawing.Size(145, 22);
            this.open3.Text = "Open Receipt";
            // 
            // save3
            // 
            this.save3.Image = ((System.Drawing.Image)(resources.GetObject("save3.Image")));
            this.save3.Name = "save3";
            this.save3.Size = new System.Drawing.Size(145, 22);
            this.save3.Text = "Save Receipt";
            // 
            // print3
            // 
            this.print3.Image = ((System.Drawing.Image)(resources.GetObject("print3.Image")));
            this.print3.Name = "print3";
            this.print3.Size = new System.Drawing.Size(145, 22);
            this.print3.Text = "Print Receipt";
            // 
            // numericUpDown15
            // 
            this.numericUpDown15.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numericUpDown15.Location = new System.Drawing.Point(258, 422);
            this.numericUpDown15.Name = "numericUpDown15";
            this.numericUpDown15.Size = new System.Drawing.Size(50, 27);
            this.numericUpDown15.TabIndex = 55;
            // 
            // numericUpDown16
            // 
            this.numericUpDown16.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numericUpDown16.Location = new System.Drawing.Point(258, 391);
            this.numericUpDown16.Name = "numericUpDown16";
            this.numericUpDown16.Size = new System.Drawing.Size(50, 27);
            this.numericUpDown16.TabIndex = 54;
            // 
            // numericUpDown17
            // 
            this.numericUpDown17.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numericUpDown17.Location = new System.Drawing.Point(258, 360);
            this.numericUpDown17.Name = "numericUpDown17";
            this.numericUpDown17.Size = new System.Drawing.Size(50, 27);
            this.numericUpDown17.TabIndex = 53;
            // 
            // numericUpDown18
            // 
            this.numericUpDown18.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numericUpDown18.Location = new System.Drawing.Point(258, 329);
            this.numericUpDown18.Name = "numericUpDown18";
            this.numericUpDown18.Size = new System.Drawing.Size(50, 27);
            this.numericUpDown18.TabIndex = 52;
            // 
            // numericUpDown19
            // 
            this.numericUpDown19.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numericUpDown19.Location = new System.Drawing.Point(258, 298);
            this.numericUpDown19.Name = "numericUpDown19";
            this.numericUpDown19.Size = new System.Drawing.Size(50, 27);
            this.numericUpDown19.TabIndex = 51;
            // 
            // numericUpDown20
            // 
            this.numericUpDown20.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numericUpDown20.Location = new System.Drawing.Point(258, 267);
            this.numericUpDown20.Name = "numericUpDown20";
            this.numericUpDown20.Size = new System.Drawing.Size(50, 27);
            this.numericUpDown20.TabIndex = 50;
            // 
            // numericUpDown21
            // 
            this.numericUpDown21.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numericUpDown21.Location = new System.Drawing.Point(258, 236);
            this.numericUpDown21.Name = "numericUpDown21";
            this.numericUpDown21.Size = new System.Drawing.Size(50, 27);
            this.numericUpDown21.TabIndex = 49;
            // 
            // numericUpDown22
            // 
            this.numericUpDown22.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numericUpDown22.Location = new System.Drawing.Point(258, 205);
            this.numericUpDown22.Name = "numericUpDown22";
            this.numericUpDown22.Size = new System.Drawing.Size(50, 27);
            this.numericUpDown22.TabIndex = 48;
            // 
            // numericUpDown23
            // 
            this.numericUpDown23.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numericUpDown23.Location = new System.Drawing.Point(258, 174);
            this.numericUpDown23.Name = "numericUpDown23";
            this.numericUpDown23.Size = new System.Drawing.Size(50, 27);
            this.numericUpDown23.TabIndex = 47;
            // 
            // numericUpDown24
            // 
            this.numericUpDown24.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numericUpDown24.Location = new System.Drawing.Point(258, 143);
            this.numericUpDown24.Name = "numericUpDown24";
            this.numericUpDown24.Size = new System.Drawing.Size(50, 27);
            this.numericUpDown24.TabIndex = 46;
            // 
            // numericUpDown25
            // 
            this.numericUpDown25.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numericUpDown25.Location = new System.Drawing.Point(258, 112);
            this.numericUpDown25.Name = "numericUpDown25";
            this.numericUpDown25.Size = new System.Drawing.Size(50, 27);
            this.numericUpDown25.TabIndex = 45;
            // 
            // numericUpDown26
            // 
            this.numericUpDown26.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numericUpDown26.Location = new System.Drawing.Point(258, 81);
            this.numericUpDown26.Name = "numericUpDown26";
            this.numericUpDown26.Size = new System.Drawing.Size(50, 27);
            this.numericUpDown26.TabIndex = 44;
            // 
            // numericUpDown27
            // 
            this.numericUpDown27.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numericUpDown27.Location = new System.Drawing.Point(258, 50);
            this.numericUpDown27.Name = "numericUpDown27";
            this.numericUpDown27.Size = new System.Drawing.Size(50, 27);
            this.numericUpDown27.TabIndex = 43;
            // 
            // numericUpDown28
            // 
            this.numericUpDown28.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.numericUpDown28.Location = new System.Drawing.Point(258, 19);
            this.numericUpDown28.Name = "numericUpDown28";
            this.numericUpDown28.Size = new System.Drawing.Size(50, 27);
            this.numericUpDown28.TabIndex = 42;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(924, 530);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Sale Point System Plus+";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numTequila)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSake)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numGin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numRum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numWhiskey)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numWIne)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numVodka)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCheese)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numWheat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numRice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSmokedFish)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numFish)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSmokedHam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numBacon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numBeef)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numMeatballs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCoriander)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSpring)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numOnions)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCelery)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCarrots)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCucumbers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numGrapes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numLettuce)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numBeans)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numMushrooms)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTomatoes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numBroccoli)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.contextMenuStrip2.ResumeLayout(false);
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown28)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem order;
        private System.Windows.Forms.ToolStripMenuItem categories;
        private System.Windows.Forms.ToolStripMenuItem receipt;
        private System.Windows.Forms.ToolStripMenuItem send;
        private System.Windows.Forms.ToolStripMenuItem clear;
        private System.Windows.Forms.ToolStripMenuItem close;
        private System.Windows.Forms.ToolStripMenuItem veg;
        private System.Windows.Forms.ToolStripMenuItem broc;
        private System.Windows.Forms.ToolStripMenuItem tomatoes;
        private System.Windows.Forms.ToolStripMenuItem mushrooms;
        private System.Windows.Forms.ToolStripMenuItem beans;
        private System.Windows.Forms.ToolStripMenuItem lettuce;
        private System.Windows.Forms.ToolStripMenuItem grapes;
        private System.Windows.Forms.ToolStripMenuItem cucumber;
        private System.Windows.Forms.ToolStripMenuItem carrots;
        private System.Windows.Forms.ToolStripMenuItem celery;
        private System.Windows.Forms.ToolStripMenuItem onions;
        private System.Windows.Forms.ToolStripMenuItem springO;
        private System.Windows.Forms.ToolStripMenuItem coriander;
        private System.Windows.Forms.ToolStripMenuItem allV;
        private System.Windows.Forms.ToolStripMenuItem meat;
        private System.Windows.Forms.ToolStripMenuItem meatballs;
        private System.Windows.Forms.ToolStripMenuItem beef;
        private System.Windows.Forms.ToolStripMenuItem bacon;
        private System.Windows.Forms.ToolStripMenuItem smokedHam;
        private System.Windows.Forms.ToolStripMenuItem fish;
        private System.Windows.Forms.ToolStripMenuItem smokedFish;
        private System.Windows.Forms.ToolStripMenuItem allM;
        private System.Windows.Forms.ToolStripMenuItem grains;
        private System.Windows.Forms.ToolStripMenuItem rice;
        private System.Windows.Forms.ToolStripMenuItem wheat;
        private System.Windows.Forms.ToolStripMenuItem allG;
        private System.Windows.Forms.ToolStripMenuItem dairy;
        private System.Windows.Forms.ToolStripMenuItem cheese;
        private System.Windows.Forms.ToolStripMenuItem alcohol;
        private System.Windows.Forms.ToolStripMenuItem vodka;
        private System.Windows.Forms.ToolStripMenuItem wine;
        private System.Windows.Forms.ToolStripMenuItem whiskey;
        private System.Windows.Forms.ToolStripMenuItem rum;
        private System.Windows.Forms.ToolStripMenuItem gin;
        private System.Windows.Forms.ToolStripMenuItem sake;
        private System.Windows.Forms.ToolStripMenuItem tequila;
        private System.Windows.Forms.ToolStripMenuItem allA;
        private System.Windows.Forms.ToolStripMenuItem open;
        private System.Windows.Forms.ToolStripMenuItem save;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.NumericUpDown numTequila;
        private System.Windows.Forms.NumericUpDown numSake;
        private System.Windows.Forms.NumericUpDown numGin;
        private System.Windows.Forms.NumericUpDown numRum;
        private System.Windows.Forms.NumericUpDown numWhiskey;
        private System.Windows.Forms.NumericUpDown numWIne;
        private System.Windows.Forms.NumericUpDown numVodka;
        private System.Windows.Forms.NumericUpDown numCheese;
        private System.Windows.Forms.NumericUpDown numWheat;
        private System.Windows.Forms.NumericUpDown numRice;
        private System.Windows.Forms.NumericUpDown numSmokedFish;
        private System.Windows.Forms.NumericUpDown numFish;
        private System.Windows.Forms.NumericUpDown numSmokedHam;
        private System.Windows.Forms.NumericUpDown numBacon;
        private System.Windows.Forms.NumericUpDown numBeef;
        private System.Windows.Forms.NumericUpDown numMeatballs;
        private System.Windows.Forms.NumericUpDown numCoriander;
        private System.Windows.Forms.NumericUpDown numSpring;
        private System.Windows.Forms.NumericUpDown numOnions;
        private System.Windows.Forms.NumericUpDown numCelery;
        private System.Windows.Forms.NumericUpDown numCarrots;
        private System.Windows.Forms.NumericUpDown numCucumbers;
        private System.Windows.Forms.NumericUpDown numGrapes;
        private System.Windows.Forms.NumericUpDown numLettuce;
        private System.Windows.Forms.NumericUpDown numBeans;
        private System.Windows.Forms.NumericUpDown numMushrooms;
        private System.Windows.Forms.NumericUpDown numTomatoes;
        private System.Windows.Forms.NumericUpDown numBroccoli;
        private System.Windows.Forms.CheckBox chkTequila;
        private System.Windows.Forms.CheckBox chkSmokedFish;
        private System.Windows.Forms.CheckBox chkSake;
        private System.Windows.Forms.CheckBox chkGin;
        private System.Windows.Forms.CheckBox chkRum;
        private System.Windows.Forms.CheckBox chkWhiskey;
        private System.Windows.Forms.CheckBox chkWine;
        private System.Windows.Forms.CheckBox chkVodka;
        private System.Windows.Forms.CheckBox chkCheese;
        private System.Windows.Forms.CheckBox chkWheat;
        private System.Windows.Forms.CheckBox chkRice;
        private System.Windows.Forms.CheckBox chkFish;
        private System.Windows.Forms.CheckBox chkSmokedHam;
        private System.Windows.Forms.CheckBox chkBacon;
        private System.Windows.Forms.CheckBox chkBeef;
        private System.Windows.Forms.CheckBox chkMeatballs;
        private System.Windows.Forms.CheckBox chkCoriander;
        private System.Windows.Forms.CheckBox chkSpring;
        private System.Windows.Forms.CheckBox chkOnions;
        private System.Windows.Forms.CheckBox chkCelery;
        private System.Windows.Forms.CheckBox chkCarrots;
        private System.Windows.Forms.CheckBox chkCucumbers;
        private System.Windows.Forms.CheckBox chkGrapes;
        private System.Windows.Forms.CheckBox chkLettuce;
        private System.Windows.Forms.CheckBox chkBeans;
        private System.Windows.Forms.CheckBox chkMushrooms;
        private System.Windows.Forms.CheckBox chkTomatoes;
        private System.Windows.Forms.CheckBox chkBroccoli;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.TextBox txtTax;
        private System.Windows.Forms.TextBox txtSubTotal;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numericUpDown15;
        private System.Windows.Forms.NumericUpDown numericUpDown16;
        private System.Windows.Forms.NumericUpDown numericUpDown17;
        private System.Windows.Forms.NumericUpDown numericUpDown18;
        private System.Windows.Forms.NumericUpDown numericUpDown19;
        private System.Windows.Forms.NumericUpDown numericUpDown20;
        private System.Windows.Forms.NumericUpDown numericUpDown21;
        private System.Windows.Forms.NumericUpDown numericUpDown22;
        private System.Windows.Forms.NumericUpDown numericUpDown23;
        private System.Windows.Forms.NumericUpDown numericUpDown24;
        private System.Windows.Forms.NumericUpDown numericUpDown25;
        private System.Windows.Forms.NumericUpDown numericUpDown26;
        private System.Windows.Forms.NumericUpDown numericUpDown27;
        private System.Windows.Forms.NumericUpDown numericUpDown28;
        private System.Windows.Forms.ToolStripButton new2;
        private System.Windows.Forms.ToolStripButton cart2;
        private System.Windows.Forms.ToolStripButton folder2;
        private System.Windows.Forms.ToolStripButton save2;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem open3;
        private System.Windows.Forms.ToolStripMenuItem save3;
        private System.Windows.Forms.ToolStripMenuItem print3;
        private System.Windows.Forms.RichTextBox txtReceipt;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem open4;
        private System.Windows.Forms.ToolStripMenuItem save4;
    }
}

